#!/bin/sh
# Installs Dossier + Cast + VET (military) packs and the VetTest episode into /workspace/studio. Safe to run twice.
set -e
S=/workspace/studio
[ -d "$S/src/episodes" ] || { echo "can't find $S/src/episodes"; exit 1; }
mkdir -p "$S/src/episodes/vet" "$S/public/vet"
cp engine/dossier.tsx engine/cast.tsx engine/vet.tsx "$S/src/engine/"
cp episode/shots.tsx episode/index.tsx episode/timeline.json "$S/src/episodes/vet/"
cp voice_test.mp3 "$S/public/vet/voice_test.mp3"
ENG="$S/src/engine/index.ts"
for m in dossier cast vet; do grep -q "from './$m'" "$ENG" || echo "export * from './$m';" >> "$ENG"; done
IDX="$S/src/episodes/index.ts"
grep -q "from './vet'" "$IDX" || sed -i "1i import { vetTest } from './vet';" "$IDX"
grep -q "EPISODES = \[.*vetTest" "$IDX" || sed -i "s/EPISODES = \[/EPISODES = [vetTest, /" "$IDX"
echo "--- $IDX:"; cat "$IDX"
echo "OK: VET test installed."
