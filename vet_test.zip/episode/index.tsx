import { defineEpisode, Timeline } from '../../engine';
import timeline from './timeline.json';
import * as S from './shots';

// "VetTest": hook + entry 1 of the veterans listicle. Military pack only.
export const vetTest = defineEpisode('VetTest', {
  timeline: timeline as Timeline,
  shots: { ...S },
});
