import React from 'react';
import {
  ShotProps, camT, kf, easeOut, clamp,
  DOS, Chip, Stamp, Card, Checklist, CounterChip, StatusCard, PunchWord, MarkPop, DuskHills,
  Person, actionPose, FONT,
  VLOOKS, Vet, CaseFile, Medal, Headstone, Flag, NightForest, Banner, Folder, WarRoom,
} from '../../engine';

// "VetTest": the hook and entry 1 (Henry Johnson) of "7 legendary veterans". Every shot is one spoken phrase.
const G = 880;
const dark = (o: number) => <rect width={1920} height={1080} fill="#000" opacity={o} />;

// ---------------- HOOK ----------------
// H1: "They fought in the worst battles in American history."
export const H1: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.09]]))}>
    <DuskHills t={t} id="h1" sunX={1400} />
    {[0, 1, 2].map((i) => (
      <Vet key={i} pose={actionPose('walk', t + i * 7, { x: 300 + i * 330, ground: G + i * 14, scale: 1.1, speed: 3.2, facing: 1 })} look={VLOOKS.soldier} helm={i === 1 ? 'ww1' : 'ww2'} />
    ))}
    <Chip x={90} y={100} t={t} d={18} text="THE WORST BATTLES" />
  </g>
);
// H2: "Some of them survived the war"
export const H2: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.07]]))}>
    <DuskHills t={t} id="h2" sunX={600} />
    <Vet pose={actionPose('nod', t, { x: 700, ground: G + 20, scale: 1.45, facing: 1 })} look={VLOOKS.soldier} helm="ww2" />
    <Stamp x={1260} y={450} t={t} d={14} text="SURVIVED" color={DOS.green} rot={-8} size={92} />
  </g>
);
// H3: "and then lost something worse."
export const H3: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.05]]))}>
    <WarRoom />
    <Vet pose={actionPose('sad', t, { x: 520, ground: 940, scale: 1.45, facing: 1 })} look={VLOOKS.soldier} helm="ww2" />
    <Checklist
      x={1280}
      y={520}
      t={t}
      d={4}
      title="CAME HOME TO"
      items={[
        { text: 'HEALTH', at: 10, mark: 'cross', markAt: 24 },
        { text: 'MONEY', at: 20, mark: 'cross', markAt: 36 },
        { text: 'RESPECT', at: 30, mark: 'cross', markAt: 48 },
      ]}
    />
  </g>
);
// H4: "No parades waited for them."
export const H4: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.06]]))}>
    <DuskHills t={t} id="h4" sunX={1500} />
    <Banner x={960} y={640} t={t} d={2} text="WELCOME HOME" />
    <Vet pose={actionPose('walk', t, { x: 300, ground: 930, scale: 1.2, speed: 8, facing: 1, expr: 'tired' })} look={VLOOKS.soldier} helm="ww2" />
  </g>
);
// H5: "No easy peace."
export const H5: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.12]]))}>
    <NightForest t={t} id="h5" />
    <Vet pose={actionPose('sad', t, { x: 960, ground: 940, scale: 1.55, facing: 1, expr: 'tired' })} look={VLOOKS.soldier} helm="ww2" />
  </g>
);
// H6: "Seven veterans."
export const H6: React.FC<ShotProps> = ({ t }) => {
  const looks = [VLOOKS.soldierDark, VLOOKS.soldier, VLOOKS.sailorDark, VLOOKS.medic, VLOOKS.soldier, VLOOKS.pilot, VLOOKS.soldierDark];
  const helms = ['ww1', 'ww1', 'sailor', 'medic', 'ww2', 'none', 'ww2'] as const;
  return (
    <g>
      <WarRoom />
      {looks.map((lk, i) => {
        const k = clamp((t - i * 4) / 5);
        if (k <= 0) return null;
        return <Vet key={i} pose={actionPose('idle', t, { x: 260 + i * 230, ground: 800, scale: 0.8 * easeOut(k), facing: 1 })} look={lk} helm={helms[i]} />;
      })}
      <CounterChip x={650} y={940} t={t} d={0} label="VETERANS" from={0} to={7} at={2} dur={30} />
    </g>
  );
};
// H7: "Seven endings."
export const H7: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.06]]))}>
    <DuskHills t={t} id="h7" sunX={960} sunY={600} />
    {[0, 1, 2, 3, 4, 5, 6].map((i) => (
      <Headstone key={i} x={280 + i * 227} y={900} t={t} d={i * 4} scale={0.48} />
    ))}
  </g>
);
// H8: "And a few of them will surprise you."
export const H8: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.05]]))}>
    <WarRoom />
    {[0, 1, 2, 3, 4, 5, 6].map((i) => (
      <Folder key={i} x={330 + i * 210} y={i === 3 ? 520 : 640} t={t} d={i * 3} n={String(i + 1)} rot={(i - 3) * 4} scale={i === 3 ? 1.15 : 0.95} />
    ))}
    <MarkPop x={960} y={260} t={t} d={24} mark="!?" hold={40} />
  </g>
);

// ---------------- 1. HENRY JOHNSON ----------------
// J0: "Number one."
export const J0: React.FC<ShotProps> = ({ t }) => (
  <g>
    <WarRoom />
    <PunchWord x={960} y={720} t={t} d={2} text="1" color="#FFD54A" size={520} rot={-2} />
  </g>
);
// J1: "Henry Johnson was a railway porter from Albany, New York."
export const J1: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.07]]))}>
    <WarRoom />
    <CaseFile
      x={960}
      y={520}
      t={t}
      d={0}
      name="HENRY JOHNSON"
      lines={[
        { k: 'JOB', v: 'RAILWAY PORTER', at: 12 },
        { k: 'FROM', v: 'ALBANY, NEW YORK', at: 26 },
        { k: 'WAR', v: 'WORLD WAR I', at: 44 },
      ]}
    />
  </g>
);
// J2: "In May 1918, in a French forest, a German raiding party hit his post."
export const J2: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(kf(t, [[0, 900], [len, 1020]]), 540, kf(t, [[0, 1.0], [len, 1.12]]))}>
    <NightForest t={t} id="j2" />
    {[0, 1, 2].map((i) => (
      <Vet key={i} pose={actionPose('walk', t + i * 5, { x: 2000 + i * 170, ground: 900 + i * 16, scale: 1.15, speed: 4.2, facing: -1 })} look={VLOOKS.enemy} helm="ww1" helmColor="#4A4F55" />
    ))}
    <Vet pose={actionPose('idle', t, { x: 640, ground: 900, scale: 1.3, facing: 1, expr: 'worried' })} look={VLOOKS.soldierDark} helm="ww1" />
    <MarkPop x={680} y={520} t={t} d={64} mark="!" hold={50} />
    <Chip x={90} y={100} t={t} d={6} text="MAY 1918" />
    <Chip x={90} y={200} t={t} d={26} text="FRANCE" />
  </g>
);
// J3a: "Out of grenades and bullets,"
export const J3a: React.FC<ShotProps> = ({ t }) => (
  <g>
    <NightForest t={t} id="j3a" />
    <Vet pose={actionPose('shock', t, { x: 520, ground: 920, scale: 1.4, facing: 1 })} look={VLOOKS.soldierDark} helm="ww1" />
    <StatusCard x={1330} y={500} t={t} d={2} title="AMMO" rows={[{ label: 'GRENADES', from: 1, to: 0 }, { label: 'BULLETS', from: 0.8, to: 0 }]} zoom={1.2} at={8} dur={28} />
  </g>
);
// J3b: "he fought with a rifle butt, a bolo knife, and his fists."
export const J3b: React.FC<ShotProps> = ({ t, len }) => {
  const sw = Math.sin(t * 0.7);
  const hero = actionPose('idle', t, { x: 700, ground: 920, scale: 1.4, facing: 1, expr: 'shock' });
  hero.armR = { a: 100 + 70 * sw, b: 20 * sw };
  hero.armL = { a: 100 - 70 * sw, b: -20 * sw };
  hero.tilt = 6 * sw;
  return (
    <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.1]]))}>
      <NightForest t={t} id="j3b" />
      {[0, 1].map((i) => (
        <Vet key={i} pose={actionPose('sad', t + i * 3, { x: 1000 + i * 260, ground: 930, scale: 1.2, facing: -1 })} look={VLOOKS.enemy} helm="ww1" helmColor="#4A4F55" />
      ))}
      <Vet pose={hero} look={VLOOKS.soldierDark} helm="ww1" />
      <Chip x={1180} y={250} t={t} d={4} text="RIFLE BUTT" />
      <Chip x={1180} y={370} t={t} d={34} text="BOLO KNIFE" />
      <Chip x={1180} y={490} t={t} d={66} text="FISTS" />
    </g>
  );
};
// J4a: "Reports say he took twenty-one wounds,"
export const J4a: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.08]]))}>
    <NightForest t={t} id="j4a" />
    <Vet pose={actionPose('sad', t, { x: 640, ground: 920, scale: 1.5, facing: 1, expr: 'worried' })} look={VLOOKS.soldierDark} helm="ww1" />
    <CounterChip x={1000} y={470} t={t} d={4} label="WOUNDS" from={0} to={21} at={10} dur={46} zoom={1.7} />
  </g>
);
// J4b: "but he saved his wounded friend, Needham Roberts."
export const J4b: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.08]]))}>
    <NightForest t={t} id="j4b" />
    <Vet pose={actionPose('sad', t, { x: 1100, ground: 960, scale: 1.0, facing: -1, expr: 'worried' })} look={VLOOKS.soldierDark} helm="ww1" />
    <Vet pose={actionPose('point', t, { x: 740, ground: 920, scale: 1.5, facing: -1, side: 'left', expr: 'worried' })} look={VLOOKS.soldierDark} helm="ww1" />
    <Chip x={1010} y={330} t={t} d={10} text="NEEDHAM ROBERTS" />
  </g>
);
// J5: "France gave him its top medal."
export const J5: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.07]]))}>
    <WarRoom />
    <Vet pose={actionPose('salute', t - 4, { x: 560, ground: 940, scale: 1.4, facing: 1 })} look={VLOOKS.officer} helm="ww1" helmColor="#2F3E5C" />
    <Vet pose={actionPose('idle', t, { x: 1380, ground: 940, scale: 1.4, facing: -1, expr: 'happy' })} look={VLOOKS.soldierDark} helm="ww1" />
    <Medal x={960} y={170} t={t} d={6} kind="croix" scale={1.7} />
    <Chip x={760} y={900} t={t} d={20} text="FRANCE" />
  </g>
);
// J6: "America gave him nothing for decades."
export const J6: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.08]]))}>
    <WarRoom />
    <Card x={960} y={520} w={640} h={300} t={t} d={0} title="AMERICA" zoom={1.4}>
      <text x={40} y={150} fontFamily={FONT.ui} fontSize={30} letterSpacing={3} fill={DOS.ink}>MEDAL ........</text>
      <text x={40} y={210} fontFamily={FONT.ui} fontSize={30} letterSpacing={3} fill={DOS.ink}>THANKS .......</text>
      <text x={40} y={270} fontFamily={FONT.ui} fontSize={30} letterSpacing={3} fill={DOS.ink}>HELP .........</text>
    </Card>
    <Stamp x={1090} y={560} t={t} d={14} text="NOTHING" color={DOS.red} rot={-9} size={100} />
  </g>
);
// J7a: "He struggled to find work,"
export const J7a: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.06]]))}>
    <WarRoom />
    <Vet pose={actionPose('sad', t, { x: 520, ground: 940, scale: 1.45, facing: 1, expr: 'worried' })} look={VLOOKS.civilianDark} />
    <Card x={1260} y={500} w={520} h={300} t={t} d={0} title="WORK" zoom={1.3}>
      <text x={40} y={160} fontFamily={FONT.ui} fontSize={32} letterSpacing={3} fill={DOS.ink}>JOBS: 0</text>
      <text x={40} y={230} fontFamily={FONT.ui} fontSize={32} letterSpacing={3} fill={DOS.ink}>PAY: 0</text>
    </Card>
    <Stamp x={1290} y={600} t={t} d={14} text="NO WORK" color={DOS.red} rot={-8} size={84} />
  </g>
);
// J7b: "and he came home sick,"
export const J7b: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.1]]))}>
    <DuskHills t={t} id="j7b" sunX={1500} />
    {dark(0.25)}
    <Vet pose={actionPose('sad', t, { x: 860, ground: 940, scale: 1.55, facing: 1, expr: 'tired' })} look={VLOOKS.civilianDark} />
    <Chip x={1180} y={330} t={t} d={8} text="SICK" color="#E9C7C0" />
  </g>
);
// J7c: "and died in 1929, aged just thirty-six."
export const J7c: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.07]]))}>
    <DuskHills t={t} id="j7c" sunX={960} sunY={640} />
    {dark(0.35)}
    <Headstone x={640} y={930} t={t} d={4} name="HENRY JOHNSON" dates="DIED 1929" scale={1.35} />
    <CounterChip x={1050} y={520} t={t} d={20} label="AGE" from={0} to={36} at={24} dur={40} zoom={1.7} />
  </g>
);
// J8a: "His Medal of Honor came in 2015,"
export const J8a: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.06]]))}>
    <WarRoom />
    <Medal x={960} y={90} t={t} d={2} kind="moh" scale={2.1} />
    <PunchWord x={960} y={960} t={t} d={16} text="2015" color="#FFD54A" size={190} rot={-2} />
  </g>
);
// J8b: "ninety-seven years after the fight,"
export const J8b: React.FC<ShotProps> = ({ t }) => {
  const p = clamp((t - 6) / 36);
  return (
    <g>
      <WarRoom />
      <Chip x={160} y={760} t={t} d={0} text="1918" />
      <Chip x={1420} y={760} t={t} d={26} text="2015" />
      <line x1={420} y1={760} x2={420 + 960 * easeOut(p)} y2={760} stroke={DOS.paper} strokeWidth={8} strokeDasharray="22 14" />
      <CounterChip x={640} y={430} t={t} d={4} label="YEARS LATER" from={0} to={97} at={8} dur={40} zoom={1.8} />
    </g>
  );
};
// J8c: "from President Obama."
export const J8c: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.05]]))}>
    <DuskHills t={t} id="j8c" sunX={960} sunY={650} />
    {dark(0.25)}
    <Flag x={230} y={300} t={t} d={0} />
    <Vet pose={actionPose('idle', t, { x: 700, ground: 930, scale: 1.45, facing: 1 })} look={VLOOKS.suit} />
    <Headstone x={1450} y={940} t={t} d={0} rise={false} name="HENRY JOHNSON" dates="DIED 1929" scale={1.2} />
    <Medal x={kf(t, [[6, 900], [len, 1320]])} y={kf(t, [[6, 560], [len, 560]])} t={t} d={4} kind="moh" scale={1.0} />
    <Chip x={90} y={80} t={t} d={4} text="PRESIDENT OBAMA, 2015" />
  </g>
);
// J9: "He never lived to hear it."
export const J9: React.FC<ShotProps> = ({ t, len }) => (
  <g>
    <g transform={camT(960, 640, kf(t, [[0, 1.0], [len, 1.14]]))}>
      <DuskHills t={t} id="j9" sunX={960} sunY={690} />
      {dark(0.4)}
      <Headstone x={960} y={960} t={t} d={0} rise={false} name="HENRY JOHNSON" dates="DIED 1929" scale={1.5} />
      <Medal x={960} y={500} t={t} d={4} kind="moh" scale={0.75} />
    </g>
    {dark(clamp((t - (len - 36)) / 30))}
  </g>
);
