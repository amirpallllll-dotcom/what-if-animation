import React from 'react';
import {
  Hero, Pose, basePose, poseAt, kf, clamp, lerp, easeOut, backOut, faceAt, LOOKS, HEAD, LEG_LEN,
  Foreground, camT, Sparkle, FocusRings, FloatLabel, TitleCard, Glow,
  Study, Desk, Rooftop, Kitchen, KitchenIsland, KITCHEN, stand, Bedroom, bedSit, BedDuvet,
  Plate, Cookie, Mug, OpenBook, WallCalendar, ShotProps,
} from '../../engine';

// "Shukr" (gratitude): a 25 second episode, 14 shots, cut to the narrator's pauses. Pip is the viewer ("you").
const PIP = LOOKS.pipHood;
const SIS = LOOKS.sis;
const MOM = LOOKS.mom;

/** Wraps a prop so it pops in with an overshoot at frame d of the shot's clock. */
const Pop: React.FC<{ x: number; y: number; t: number; d: number; children: React.ReactNode }> = ({ x, y, t, d, children }) => {
  if (t < d) return null;
  const s = backOut(clamp((t - d) / 8));
  return <g transform={`translate(${x} ${y}) scale(${s}) translate(${-x} ${-y})`}>{children}</g>;
};

// ---------- S1: "Why do we feel empty," wide: Pip alone in the night study, tired ----------
export const S1: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { x: 960, y: 712, yaw: 0.4, look: 0.3, armR: { a: 12, b: -6 }, armL: { a: 12, b: -6 }, headTilt: 4 } },
    { f: 43, p: { headTilt: 9 } },
  ]);
  return (
    <g transform={camT(990, 545, kf(t, [[0, 0.86], [len, 0.95]]))}>
      <Study t={t} id="s1" night />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'tired']]) }} shadow={0} rimId="rimR" />
      <Desk x0={560} x1={1360} y={700} />
      <Foreground blur={10}>
        <path d="M -140 1220 L -140 860 Q -128 786 -30 786 L 236 786 Q 322 786 334 862 L 344 1220 Z" fill="#140F1A" />
        <path d="M -60 790 Q 110 776 262 790" stroke="#FFB46A" strokeWidth={4} fill="none" opacity={0.3} />
      </Foreground>
    </g>
  );
};

// ---------- S2: "even when we have so much?" medium: a plate, a cookie, a mug pop onto the desk; Pip shrugs ----------
export const S2: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { x: 940, y: 712, yaw: 0.35, look: 0.2, armR: { a: 12, b: -6 }, armL: { a: 12, b: -6 } } },
    { f: 22, p: { armR: { a: 50, b: 34 }, armL: { a: 50, b: 34 }, headTilt: 6 }, ease: easeOut },
    { f: 55, p: { armR: { a: 46, b: 30 }, armL: { a: 46, b: 30 } } },
  ]);
  return (
    <g transform={camT(kf(t, [[0, 1000], [len, 980]]), 600, kf(t, [[0, 1.7], [len, 1.85]]))}>
      <Study t={t + 60} id="s2" night />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'happy'], [34, 'tired']]) }} shadow={0} rimId="rimR" />
      <Desk x0={520} x1={1400} y={700} lamp={false} />
      <Pop x={760} y={700} t={t} d={6}>
        <Plate x={760} y={700} s={0.9} />
        <Cookie x={756} y={690} s={0.8} />
      </Pop>
      <Pop x={1150} y={700} t={t} d={14}>
        <Mug x={1150} y={700} rot={0} f={t} />
      </Pop>
      <Sparkle x={780} y={620} t={t - 9} s={0.9} />
      <Foreground blur={10}>
        <rect x={440} y={800} width={220} height={40} rx={6} fill="#120D16" />
        <rect x={452} y={762} width={200} height={40} rx={6} fill="#17111C" />
      </Foreground>
    </g>
  );
};

// ---------- S3: "Because we keep looking" extreme close-up: his eyes search left and right, the room soft behind ----------
export const S3: React.FC<ShotProps> = ({ t, len }) => {
  const sc = 3.8 * (1 + 0.04 * kf(t, [[0, 0], [len, 1]]));
  const head = { x: 1000, y: 600 };
  const look = kf(t, [[0, -0.9], [14, -0.9], [20, 0.9], [len, 0.9]]);
  const pose: Pose = { ...basePose, x: head.x, y: head.y - HEAD.y * sc, scale: sc, yaw: 0.22, look, armL: { a: 14, b: -6 }, armR: { a: 14, b: -6 }, ...faceAt(t, [[0, 'worried']]) };
  return (
    <g>
      <g filter="url(#blur16)">
        <Study t={t + 100} id="s3" night />
      </g>
      <rect x={0} y={0} width={1920} height={1080} fill="#07040C" opacity={0.3} />
      <Hero look={PIP} pose={pose} shadow={0} rimId="rimL" />
    </g>
  );
};

// ---------- S4: "at what we don't have." medium: an empty plate, he stares at it ----------
export const S4: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { x: 900, y: 712, yaw: 0.5, look: 0.9, armR: { a: 12, b: -6 }, armL: { a: 12, b: -6 }, headTilt: 8 } },
    { f: 44, p: { headTilt: 14 } },
  ]);
  return (
    <g transform={camT(kf(t, [[0, 1000], [len, 1030]]), 610, kf(t, [[0, 1.75], [len, 1.95]]))}>
      <Study t={t + 120} id="s4" night />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'worried'], [22, 'tired']]) }} shadow={0} rimId="rimR" />
      <Desk x0={520} x1={1400} y={700} lamp={false} />
      <Plate x={1150} y={700} s={0.95} />
      <Foreground blur={10}>
        <path d="M 1640 900 Q 1520 700 1560 520 Q 1600 700 1700 880 Z" fill="#0E1610" />
      </Foreground>
    </g>
  );
};

// ---------- S5: "Islam gives us a simple cure:" he raises a finger, a warm light grows by the window, the moon ----------
export const S5: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { x: 900, y: 712, yaw: 0.3, look: 0.2, armR: { a: 12, b: -6 }, armL: { a: 12, b: -6 } } },
    { f: 18, p: { armR: { a: 150, b: -6 } }, ease: easeOut },
    { f: 24, p: { armR: { a: 158, b: -4 } } },
    { f: 69, p: { armR: { a: 154, b: -4 } } },
  ]);
  const glow = lerp(0, 460, easeOut(clamp(t / 46)));
  return (
    <g transform={camT(kf(t, [[0, 960], [len, 1040]]), kf(t, [[0, 600], [len, 540]]), kf(t, [[0, 1.2], [len, 1.55]]))}>
      <Study t={t + 180} id="s5" night />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'neutral'], [16, 'happy']]), handR: t >= 16 ? 'point' : 'open' }} shadow={0} rimId="rimR" />
      <Desk x0={560} x1={1360} y={700} />
      <Glow x={1090} y={540} r={glow} kind="warm" o={0.55} />
      <Sparkle x={1130} y={430} t={t - 20} s={1.3} />
    </g>
  );
};

// ---------- S6: "Shukr. Gratitude." title card over the rooftop at dusk ----------
export const S6: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { x: 960, y: 770, scale: 0.62, yaw: 0, armL: { a: 20, b: 6 }, armR: { a: 20, b: 6 } } },
    { f: 14, p: { armL: { a: 150, b: 10 }, armR: { a: 150, b: 10 } }, ease: easeOut },
  ]);
  return (
    <g transform={camT(960, kf(t, [[0, 520], [len, 560]]), kf(t, [[0, 1.0], [len, 1.08]]))}>
      <Rooftop t={t + 200} sunY={kf(t, [[0, 690], [len, 650]])} />
      <Hero look={PIP} pose={{ ...pose, y: 820 - LEG_LEN * 0.62, ...faceAt(t, [[0, 'happy']]) }} shadow={0.6} rimId="rimR" />
      <TitleCard t={t} lines={['THE SIMPLE CURE', 'IS SHUKR']} accent="SHUKR" accentT={30} />
    </g>
  );
};

// ---------- S7: "The Quran teaches that gratitude" macro: an open book glows on the desk, a page turns ----------
export const S7: React.FC<ShotProps> = ({ t, len }) => {
  const turn = clamp((t - 12) / 24);
  return (
    <g transform={camT(960, 680, kf(t, [[0, 1.25], [len, 1.5]]))}>
      <g filter="url(#blur6)">
        <Study t={t + 240} id="s7" night />
      </g>
      <rect x={0} y={0} width={1920} height={1080} fill="#07040C" opacity={0.35} />
      <Glow x={960} y={660} r={lerp(200, 520, easeOut(clamp(t / 40)))} kind="warm" o={0.6} />
      <OpenBook x={960} y={780} w={720} turn={turn} />
      <Sparkle x={820} y={560} t={t - 18} s={1.4} />
      <Sparkle x={1120} y={540} t={t - 26} s={1.1} />
    </g>
  );
};

// ---------- S8: "brings more blessings." medium: Pip smiles, "+1" floats up again and again ----------
export const S8: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { x: 940, y: 712, yaw: 0.3, look: 0.2, armR: { a: 40, b: 10 }, armL: { a: 40, b: 10 } } },
    { f: 12, p: { armR: { a: 70, b: 14 }, armL: { a: 70, b: 14 } }, ease: easeOut },
    { f: 46, p: { armR: { a: 56, b: 10 }, armL: { a: 56, b: 10 } } },
  ]);
  return (
    <g transform={camT(kf(t, [[0, 1000], [len, 980]]), 590, kf(t, [[0, 1.7], [len, 1.85]]))}>
      <Study t={t + 300} id="s8" night />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'happy']]) }} shadow={0} rimId="rimR" />
      <Desk x0={520} x1={1400} y={700} />
      <FloatLabel x={1180} y={480} t={t - 2} text="+1" />
      <FloatLabel x={760} y={430} t={t - 12} text="+1" />
      <FloatLabel x={1260} y={560} t={t - 22} text="+1" />
      <FloatLabel x={700} y={520} t={t - 32} text="+1" />
      <Sparkle x={1100} y={420} t={t - 6} s={1.2} />
    </g>
  );
};

// ---------- S9: "Start with three things every night." wide: Pip sits up in bed at night, the lamp on ----------
export const S9: React.FC<ShotProps> = ({ t, len }) => {
  const bs = bedSit(0.2);
  const pose = poseAt(t, [
    { f: 0, p: { x: bs.x, y: bs.y, scale: bs.scale, yaw: 0.3, look: 0.4, armR: { a: 14, b: -6 }, armL: { a: 14, b: -6 } } },
    { f: 22, p: { armR: { a: 60, b: 24 } }, ease: easeOut },
    { f: 65, p: { armR: { a: 24, b: 4 } } },
  ]);
  return (
    <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.14]]))}>
      <Bedroom t={t} id="s9" duvet={false} clock="22:30" crossed={0} />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'tired'], [20, 'neutral']]) }} shadow={0} rimId="rimR" />
      <BedDuvet />
    </g>
  );
};

// ---------- S10: "One. Your health." closer on the bed: a big "1" floats up, soft rings round his chest ----------
export const S10: React.FC<ShotProps> = ({ t, len }) => {
  const bs = bedSit(0.2);
  const pose = poseAt(t, [
    { f: 0, p: { x: bs.x, y: bs.y, scale: bs.scale, yaw: 0.25, look: 0.2, armR: { a: 24, b: 4 }, armL: { a: 14, b: -6 } } },
    { f: 10, p: { armR: { a: 12, b: 70 } }, ease: easeOut },
  ]);
  return (
    <g transform={camT(bs.x + 60, bs.y - 110, kf(t, [[0, 1.8], [len, 2.0]]))}>
      <Bedroom t={t + 65} id="s10" duvet={false} clock="22:31" crossed={0} />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'neutral'], [10, 'happy']]) }} shadow={0} rimId="rimR" />
      <BedDuvet />
      <FocusRings x={bs.x + 4} y={bs.y - 110 * bs.scale} t={t - 10} />
      <FloatLabel x={bs.x + 230} y={bs.y - 280} t={t - 6} text="1" size={150} />
    </g>
  );
};

// ---------- S11: "Two. Your family." the kitchen: mum, Pip and his little sister together ----------
const K = { mom: stand(KITCHEN, 0.28, 0.4), pip: stand(KITCHEN, 0.5, 0.4), sis: stand(KITCHEN, 0.72, 0.4) };
const sisS = K.sis.scale * 0.72;
const sisY = K.sis.y + LEG_LEN * K.sis.scale - LEG_LEN * sisS;
export const S11: React.FC<ShotProps> = ({ t, len }) => {
  const wave = Math.sin(t * 0.55) * 8;
  const pipP = poseAt(t, [
    { f: 0, p: { x: K.pip.x, y: K.pip.y, scale: K.pip.scale, yaw: 0, armR: { a: 14, b: -6 }, armL: { a: 14, b: -6 } } },
    { f: 12, p: { armR: { a: 40, b: 10 }, armL: { a: 40, b: 10 } }, ease: easeOut },
  ]);
  return (
    <g transform={camT(kf(t, [[0, 960], [len, 975]]), 600, kf(t, [[0, 1.55], [len, 1.7]]))}>
      <Kitchen t={t + 80} id="s11" />
      <Hero look={MOM} pose={{ ...basePose, x: K.mom.x, y: K.mom.y, scale: K.mom.scale, yaw: 0.2, armR: { a: 20, b: 6 }, armL: { a: 20, b: 6 }, ...faceAt(t, [[0, 'happy']]) }} shadow={0} rimId="rimR" />
      <Hero look={PIP} pose={{ ...pipP, ...faceAt(t, [[0, 'happy']]) }} shadow={0} rimId="rimR" />
      <Hero look={SIS} pose={{ ...basePose, x: K.sis.x, y: sisY, scale: sisS, yaw: -0.2, armR: { a: 130 + wave, b: 8 }, armL: { a: 14, b: -6 }, ...faceAt(t, [[0, 'happy']]) }} shadow={0} rimId="rimL" />
      <KitchenIsland />
      <Sparkle x={K.pip.x} y={K.pip.y - 360 * K.pip.scale} t={t - 14} s={1.2} />
    </g>
  );
};

// ---------- S12: "Three. Your faith." night window: the crescent moon glows, a calm light pulses ----------
export const S12: React.FC<ShotProps> = ({ t, len }) => {
  const pulse = 1 + 0.08 * Math.sin(t * 0.22);
  return (
    <g transform={camT(kf(t, [[0, 1110], [len, 1130]]), kf(t, [[0, 500], [len, 470]]), kf(t, [[0, 1.7], [len, 2.0]]))}>
      <Study t={t + 400} id="s12" night />
      <Glow x={1135} y={428} r={260 * pulse} kind="cool" o={0.6} />
      <Sparkle x={1150} y={420} t={t - 8} s={1.5} />
      <Sparkle x={1010} y={500} t={t - 20} s={1.0} />
      <Foreground blur={16}>
        <path d="M -200 1250 L -200 700 Q -100 560 120 600 Q 330 640 380 1250 Z" fill="#0C0814" />
      </Foreground>
    </g>
  );
};

// ---------- S13: "Do this for seven days." the calendar: a red cross drawn on each day, seven times ----------
export const S13: React.FC<ShotProps> = ({ t, len }) => {
  const per = 7;
  const day = Math.min(7, Math.floor(t / per));
  const drawing = day < 7 ? (t % per) / per : 0;
  return (
    <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.12]]))}>
      <rect x={-200} y={-200} width={2320} height={1480} fill="#15182A" />
      <Glow x={960} y={540} r={640} kind="warm" o={0.35} />
      <WallCalendar x={960} y={160} w={640} crossed={day} drawing={drawing} />
      <Sparkle x={1380} y={300} t={t - 52} s={1.6} />
    </g>
  );
};

// ---------- S14: "And watch your heart change." low angle on the rooftop at sunrise: Pip, arms up, sparkles ----------
export const S14: React.FC<ShotProps> = ({ t, len }) => {
  const pose = poseAt(t, [
    { f: 0, p: { x: 900, y: 790, scale: 1.8, yaw: 0.15, armL: { a: 20, b: 6 }, armR: { a: 150, b: 30 } } },
    { f: 49, p: { armR: { a: 162, b: 20 }, armL: { a: 150, b: 20 } } },
  ]);
  return (
    <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.06]]))}>
      <Rooftop t={t + 300} sunX={1050} sunY={kf(t, [[0, 600], [len, 500]])} low={260} />
      <Hero look={PIP} pose={{ ...pose, ...faceAt(t, [[0, 'happy']]) }} shadow={0} rimId="rimR" />
      <Sparkle x={620} y={380} t={t - 4} s={1.5} />
      <Sparkle x={1240} y={300} t={t - 14} s={1.1} />
      <Sparkle x={1160} y={640} t={t - 24} s={0.9} />
    </g>
  );
};
