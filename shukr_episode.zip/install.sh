#!/bin/sh
# Run from the folder that holds this file:  sh install.sh
# It copies the Shukr episode into /workspace/studio and registers it. Safe to run twice.
set -e
S=/workspace/studio
[ -d "$S/src/episodes" ] || { echo "can't find $S/src/episodes"; exit 1; }
mkdir -p "$S/src/episodes/shukr" "$S/public/shukr"
cp episode/shots.tsx episode/index.tsx episode/timeline.json "$S/src/episodes/shukr/"
cp voice.mp3 "$S/public/shukr/voice.mp3"
IDX="$S/src/episodes/index.ts"
grep -q "from './shukr'" "$IDX" || sed -i "1i import { shukr } from './shukr';" "$IDX"
grep -q "shukr" "$IDX" && ! grep -q "EPISODES = \[.*shukr" "$IDX" && sed -i "s/EPISODES = \[/EPISODES = [shukr, /" "$IDX"
echo "--- $IDX:"; cat "$IDX"
echo "OK. Now run:  cd $S && npx remotion still src/index.ts Shukr /workspace/shukr_S6.png --frame=290 --browser-executable=/usr/bin/chromium --chrome-mode=chrome-for-testing"
