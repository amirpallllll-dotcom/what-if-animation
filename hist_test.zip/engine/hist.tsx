import React from 'react';
import { clamp, easeOut, backOut } from './anim';
import { FONT } from './fonts';
import { Hero, Pose, Look, joints, toWorld } from './rig';
import { CAST, actionPose, ActionName, ActOpts } from './cast';

// The HIST pack (ancient-war comedy niche): people with beards, eye patches and plumed helmets, angry/sad brows, tears,
// a camp set, an ideas board with a red X, speech captions with word pop, swords, torches, fire, smoke and a cartoon fireball.
// Same flat look as the Cast kit. World is 1920 x 1080; every piece is a pure function of the shot clock t (frames).
// Never import this from another niche.

const INK = '#14121C';

export const HLOOKS = {
  puni: { ...CAST.soldier, jacket: '#F1ECDD', jacketShade: '#D9D2BE', limb: '#F1ECDD', accent: '#B03A2E' } as Look,
  captain: { ...CAST.officer, jacket: '#B9A247', jacketShade: '#9A8536', limb: '#B9A247', accent: '#7B3F9E' } as Look,
  legion: { ...CAST.soldier, jacket: '#B83A2E', jacketShade: '#942E24', limb: '#B83A2E', accent: '#E7C766' } as Look,
  toga: { ...CAST.elder, jacket: '#F4F0E4', jacketShade: '#DCD5C2', limb: '#F4F0E4', accent: '#B03A2E' } as Look,
};

// ---------- people ----------
export type HAcc = {
  helm?: 'pointed' | 'crest' | 'plume' | 'none';
  helmColor?: string;
  beard?: boolean;
  patch?: 'l' | 'r';
  brows?: 'angry' | 'sad' | 'stern';
  mouth?: 'shout' | 'ooh';
  tears?: boolean;
  hurt?: boolean;
};

// Head space: centre (0,0), radius about 70, eyes at (+-24, -4), mouth at (0, 35), helmet brim at y = -30.
const HHead: React.FC<{ acc: HAcc; t: number }> = ({ acc, t }) => {
  const k = (t * 1.5) % 30;
  return (
    <g>
      {acc.beard ? <path d="M -64 2 Q -68 72 0 86 Q 68 72 64 2 Q 40 26 0 22 Q -40 26 -64 2 Z" fill="#17141A" stroke={INK} strokeWidth={4} strokeLinejoin="round" /> : null}
      {acc.mouth === 'shout' ? <ellipse cx={0} cy={38} rx={22} ry={26} fill="#3A1420" stroke={INK} strokeWidth={4} /> : null}
      {acc.mouth === 'ooh' ? <ellipse cx={0} cy={40} rx={13} ry={18} fill="#3A1420" stroke={INK} strokeWidth={4} /> : null}
      {acc.patch ? (
        <g>
          <path d="M -68 -30 L 68 -36" stroke={INK} strokeWidth={5} />
          <ellipse cx={acc.patch === 'l' ? -24 : 24} cy={-4} rx={23} ry={18} fill={INK} stroke={INK} strokeWidth={3} />
        </g>
      ) : null}
      {acc.brows === 'angry' || acc.brows === 'stern' ? (
        <g stroke={INK} strokeWidth={8} strokeLinecap="round">
          <line x1={-46} y1={acc.brows === 'angry' ? -28 : -22} x2={-8} y2={-12} />
          <line x1={46} y1={acc.brows === 'angry' ? -28 : -22} x2={8} y2={-12} />
        </g>
      ) : null}
      {acc.brows === 'sad' ? (
        <g stroke={INK} strokeWidth={7} strokeLinecap="round">
          <line x1={-44} y1={-14} x2={-8} y2={-28} />
          <line x1={44} y1={-14} x2={8} y2={-28} />
        </g>
      ) : null}
      {acc.tears ? (
        <g fill="#7EC8F0" stroke={INK} strokeWidth={2}>
          <path d="M -30 8 Q -36 24 -30 40" fill="none" stroke="#7EC8F0" strokeWidth={6} strokeLinecap="round" />
          <path d="M 30 8 Q 36 24 30 40" fill="none" stroke="#7EC8F0" strokeWidth={6} strokeLinecap="round" />
          <circle cx={-32} cy={14 + k} r={6} opacity={1 - k / 30} />
          <circle cx={32} cy={14 + ((k + 14) % 30)} r={6} opacity={1 - ((k + 14) % 30) / 30} />
        </g>
      ) : null}
      {acc.hurt ? (
        <g>
          <rect x={-54} y={-56} width={108} height={22} rx={7} fill="#F4F0E4" stroke={INK} strokeWidth={4} transform="rotate(-7)" />
          <path d="M 28 8 L 54 18 M 26 24 L 52 34 M 30 -4 L 50 2" stroke="#C8402F" strokeWidth={5} strokeLinecap="round" />
        </g>
      ) : null}
      {acc.helm === 'pointed' ? (
        <g>
          <path d="M -66 -30 Q -62 -80 0 -116 Q 62 -80 66 -30 Q 0 -44 -66 -30 Z" fill={acc.helmColor ?? '#D9C28A'} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -68 -32 Q 0 -46 68 -32" stroke="#B09A62" strokeWidth={6} fill="none" />
        </g>
      ) : null}
      {acc.helm === 'crest' ? (
        <g>
          <path d="M -34 -96 Q 0 -160 70 -124 Q 48 -104 34 -96 Z" fill="#8E44AD" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -68 -30 Q -68 -98 0 -100 Q 68 -98 68 -30 Q 0 -44 -68 -30 Z" fill={acc.helmColor ?? '#C9A24A'} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -72 -32 Q 0 -46 72 -32 L 70 -24 Q 0 -38 -70 -24 Z" fill="#9A7B2F" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        </g>
      ) : null}
      {acc.helm === 'plume' ? (
        <g>
          <path d="M -4 -98 Q -22 -142 2 -156 Q 26 -140 12 -98 Z" fill="#2E5AAC" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
          <path d="M -66 -30 Q -66 -98 0 -100 Q 66 -98 66 -30 Q 0 -44 -66 -30 Z" fill={acc.helmColor ?? '#D9C28A'} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -70 -32 Q 0 -46 70 -32 L 68 -24 Q 0 -38 -68 -24 Z" fill="#B09A62" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        </g>
      ) : null}
    </g>
  );
};

export const Hist: React.FC<{ pose: Pose; look?: Look; acc?: HAcc; t?: number; shadow?: number }> = ({ pose, look = HLOOKS.puni, acc = {}, t = 0, shadow = 0.6 }) => {
  const hd = toWorld(pose, joints(pose).head);
  return (
    <g>
      <Hero look={look} pose={pose} shadow={shadow} />
      <g transform={`translate(${hd.x} ${hd.y}) rotate(${pose.tilt + pose.headTilt + pose.spin}) scale(${pose.scale})`}>
        <HHead acc={acc} t={t} />
      </g>
    </g>
  );
};

export type HAction = ActionName | 'facepalm' | 'cry' | 'draw' | 'torch' | 'lie' | 'triumph' | 'roll';
const STD: string[] = ['idle', 'walk', 'run', 'point', 'salute', 'bow', 'shrug', 'wave', 'cheer', 'shock', 'sad', 'think', 'nod'];

/** The Cast actions plus: facepalm cry draw (arm moves like writing on a board) torch (run with a raised arm) lie (fallen) triumph roll (somersault). */
export const histPose = (name: HAction, t: number, o: ActOpts): Pose => {
  if (STD.includes(name)) return actionPose(name as ActionName, t, o);
  const f = o.facing ?? 1;
  const tt = Math.max(0, t);
  const sc = o.scale ?? 1;
  const base = actionPose('idle', t, o);
  switch (name) {
    case 'facepalm': {
      const k = easeOut(clamp(tt / 8));
      return { ...base, armR: { a: 8 + 50 * k, b: -6 + 150 * k }, headTilt: 10 * k * f, tilt: 6 * k * f, expr: o.expr ?? 'tired' };
    }
    case 'cry': {
      const k = easeOut(clamp(tt / 10));
      const sh = Math.sin(tt * 0.8) * 2;
      return { ...base, tilt: 18 * k * f + sh, headTilt: 14 * k * f, armR: { a: 8 + 50 * k, b: -6 + 150 * k }, armL: { a: 8 + 50 * k, b: -6 + 150 * k }, expr: o.expr ?? 'worried' };
    }
    case 'draw': {
      const s = Math.sin(tt * 0.6);
      return { ...base, armR: { a: 125 + 10 * s, b: 6 * s }, headTilt: 3 * f, expr: o.expr ?? 'neutral', look: 0.7 * f };
    }
    case 'torch': {
      const p = actionPose('run', t, o);
      return { ...p, armR: { a: 140, b: -6 }, expr: o.expr ?? 'worried' };
    }
    case 'lie':
      return { ...base, tilt: 88 * f, y: o.ground - 36 * sc, armR: { a: 20, b: 0 }, armL: { a: 20, b: 0 }, expr: o.expr ?? 'dizzy' };
    case 'triumph':
      return { ...base, armR: { a: 160, b: 8 }, armL: { a: 160, b: 8 }, expr: o.expr ?? 'smug', y: base.y - 4 * Math.sin(tt * 0.2) };
    case 'roll': {
      const p = actionPose('run', t, o);
      const k = clamp(tt / 22);
      return { ...p, tilt: 360 * k * f, y: p.y - 70 * Math.sin(Math.PI * k) * sc };
    }
    default:
      return base;
  }
};

// ---------- props ----------
export const HSword: React.FC<{ x: number; y: number; s?: number; rot?: number }> = ({ x, y, s = 1, rot = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <path d="M -7 0 L -7 -150 L 0 -176 L 7 -150 L 7 0 Z" fill="#C9CED2" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
    <path d="M 0 -4 L 0 -150" stroke="#9AA1A8" strokeWidth={3} />
    <rect x={-24} y={-4} width={48} height={11} rx={4} fill="#8A6B2B" stroke={INK} strokeWidth={3} />
    <rect x={-5} y={7} width={10} height={30} fill="#5A3A1E" stroke={INK} strokeWidth={3} />
    <circle cx={0} cy={40} r={8} fill="#8A6B2B" stroke={INK} strokeWidth={3} />
  </g>
);

export const HFlame: React.FC<{ x: number; y: number; s?: number; t: number; seed?: number }> = ({ x, y, s = 1, t, seed = 0 }) => {
  const fl = 1 + 0.12 * Math.sin(t * 0.6 + seed * 3) + 0.06 * Math.sin(t * 1.3 + seed);
  return (
    <g transform={`translate(${x} ${y}) scale(${s} ${s * fl})`}>
      <path d="M 0 0 Q -30 -10 -24 -46 Q -18 -72 0 -104 Q 16 -72 24 -46 Q 30 -10 0 0 Z" fill="#F5A623" stroke={INK} strokeWidth={3} strokeLinejoin="round" />
      <path d="M 0 0 Q -15 -6 -12 -26 Q -8 -40 0 -58 Q 8 -40 12 -26 Q 15 -6 0 0 Z" fill="#F7D154" />
    </g>
  );
};

export const HTorch: React.FC<{ x: number; y: number; s?: number; t: number; rot?: number }> = ({ x, y, s = 1, t, rot = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <rect x={-6} y={-70} width={12} height={80} rx={4} fill="#5A3A1E" stroke={INK} strokeWidth={3} />
    <HFlame x={0} y={-66} s={0.55} t={t} seed={x} />
  </g>
);

export const HSmoke: React.FC<{ x: number; y: number; s?: number; t: number; n?: number }> = ({ x, y, s = 1, t, n = 4 }) => (
  <g>
    {Array.from({ length: n }, (_, i) => {
      const ph = ((t * 0.6 + i * (80 / n)) % 80) / 80;
      return <circle key={i} cx={x + Math.sin(i * 2 + ph * 3) * 20 * s} cy={y - ph * 170 * s} r={(18 + ph * 40) * s} fill="#5A5550" opacity={0.55 * (1 - ph)} />;
    })}
  </g>
);

export const HFireball: React.FC<{ x: number; y: number; s?: number; t: number; d?: number }> = ({ x, y, s = 1, t, d = 0 }) => {
  if (t < d) return null;
  const k = clamp((t - d) / 16);
  const e = easeOut(k);
  const fade = 1 - clamp((t - d - 26) / 24);
  const lobes = [0, 1, 2, 3, 4, 5];
  return (
    <g opacity={fade} transform={`translate(${x} ${y}) scale(${s})`}>
      <circle cx={0} cy={-60 * e} r={150 * e} fill="#3A3633" opacity={0.55} />
      {lobes.map((i) => (
        <circle key={i} cx={Math.cos(i * 1.05) * 80 * e} cy={Math.sin(i * 1.05) * 60 * e - 40 * e} r={80 * e} fill="#D6442B" stroke={INK} strokeWidth={4} />
      ))}
      {lobes.map((i) => (
        <circle key={'o' + i} cx={Math.cos(i * 1.05 + 0.5) * 50 * e} cy={Math.sin(i * 1.05 + 0.5) * 40 * e - 40 * e} r={56 * e} fill="#F5A623" />
      ))}
      <circle cx={0} cy={-40 * e} r={48 * e} fill="#F7D154" />
    </g>
  );
};

export const HPuddle: React.FC<{ x: number; y: number; s?: number; t: number; d?: number }> = ({ x, y, s = 1, t, d = 0 }) => (
  <ellipse cx={x} cy={y} rx={70 * s * easeOut(clamp((t - d) / 12))} ry={14 * s * easeOut(clamp((t - d) / 12))} fill="#B8322A" stroke={INK} strokeWidth={3} />
);

// ---------- caption: speech text that pops in word by word, with a speaker tick ----------
export const HCaption: React.FC<{ t: number; x?: number; y?: number; words: [string, number][]; size?: number; tick?: { x: number; y: number } }> = ({ t, x = 960, y = 180, words, size = 64, tick }) => {
  const cw = size * 0.58;
  const total = words.reduce((a, w) => a + (w[0].length + 1) * cw, 0) - cw;
  let cur = x - total / 2;
  const first = words.length ? words[0][1] : 0;
  return (
    <g>
      {tick && t >= first ? <path d={`M ${tick.x - 14} ${tick.y} L ${tick.x} ${tick.y - 22} M ${tick.x + 2} ${tick.y + 2} L ${tick.x + 6} ${tick.y - 24}`} stroke="#FFFFFF" strokeWidth={5} strokeLinecap="round" /> : null}
      {words.map(([w, at], i) => {
        const px = cur;
        cur += (w.length + 1) * cw;
        if (t < at) return null;
        const k = backOut(clamp((t - at) / 5));
        return (
          <text key={i} x={px + (w.length * cw) / 2} y={y} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={size} fill="#FFFFFF" stroke={INK} strokeWidth={size * 0.16} strokeLinejoin="round" paintOrder="stroke" transform={`translate(0 ${(1 - k) * 12})`} opacity={clamp((t - at) / 3)}>
            {w}
          </text>
        );
      })}
    </g>
  );
};

// ---------- ideas board ----------
export type HBoardItem = { text: string; mark?: 'x' | 'check'; at?: number };
export const HBoard: React.FC<{ x: number; y: number; w?: number; h?: number; t: number; d?: number; title: string; items: HBoardItem[]; ground?: number }> = ({ x, y, w = 640, h = 400, t, d = 0, title, items, ground = 900 }) => {
  const k = easeOut(clamp((t - d) / 8));
  return (
    <g opacity={k}>
      <path d={`M ${x + 60} ${y + h} L ${x + 10} ${ground} M ${x + w - 60} ${y + h} L ${x + w - 10} ${ground}`} stroke="#6E4521" strokeWidth={14} strokeLinecap="round" />
      <rect x={x} y={y} width={w} height={h} rx={8} fill="#FBFBF6" stroke={INK} strokeWidth={7} />
      <text x={x + w / 2} y={y + 56} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={40} letterSpacing={3} fill={INK}>{title}</text>
      <line x1={x + 90} y1={y + 70} x2={x + w - 90} y2={y + 70} stroke={INK} strokeWidth={4} />
      {items.map((it, i) => {
        const iy = y + 128 + i * 76;
        const m = it.at !== undefined ? clamp((t - it.at) / 12) : 1;
        const m1 = clamp(m * 2);
        const m2 = clamp(m * 2 - 1);
        const tw = it.text.length * 24;
        return (
          <g key={i}>
            <text x={x + 40} y={iy} fontFamily={FONT.hand} fontWeight={800} fontSize={42} fill={INK}>{it.text}</text>
            {it.mark === 'x' && m > 0 ? (
              <g stroke="#D6282A" strokeWidth={10} strokeLinecap="round">
                <line x1={x + 30} y1={iy - 40} x2={x + 30 + (tw + 20) * m1} y2={iy - 40 + 52 * m1} />
                {m2 > 0 ? <line x1={x + 30 + tw + 20} y1={iy - 40} x2={x + 30 + tw + 20 - (tw + 20) * m2} y2={iy - 40 + 52 * m2} /> : null}
              </g>
            ) : null}
            {it.mark === 'check' && m > 0 ? <path d={`M ${x + w - 120} ${iy - 16} L ${x + w - 95} ${iy + 6} L ${x + w - 50} ${iy - 40}`} stroke="#2E9E4F" strokeWidth={10} fill="none" strokeLinecap="round" strokeLinejoin="round" opacity={m1} /> : null}
          </g>
        );
      })}
    </g>
  );
};

// ---------- sets ----------
export const HCamp: React.FC<{ variant?: 1 | 2 }> = ({ variant = 1 }) => (
  <g>
    <rect width={1920} height={1080} fill="#BBD9EA" />
    <rect y={150} width={1920} height={560} fill="#8A5A2B" />
    {Array.from({ length: 33 }, (_, i) => (
      <g key={i}>
        <path d={`M ${i * 60} 150 L ${i * 60 + 30} 110 L ${i * 60 + 60} 150 Z`} fill="#7A4D24" stroke={INK} strokeWidth={3} />
        <line x1={i * 60} y1={150} x2={i * 60} y2={710} stroke="#6E4521" strokeWidth={4} />
      </g>
    ))}
    <rect y={700} width={1920} height={380} fill="#C9A36A" />
    <rect y={700} width={1920} height={8} fill="#A98450" />
    {/* tent */}
    <g transform={`translate(${variant === 1 ? 230 : 1560} 0)`}>
      <path d="M -190 700 L 0 430 L 190 700 Z" fill="#E8DCBD" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <path d="M -50 700 L 0 560 L 50 700 Z" fill="#3A2A1E" />
    </g>
    {/* barrel */}
    <g transform={`translate(${variant === 1 ? 1700 : 330} 0)`}>
      <rect x={-50} y={600} width={100} height={110} rx={14} fill="#8A5A2B" stroke={INK} strokeWidth={5} />
      <path d="M -50 630 H 50 M -50 680 H 50" stroke={INK} strokeWidth={5} />
    </g>
    {/* ladder */}
    <g stroke="#5A3A1E" strokeWidth={9} strokeLinecap="round">
      <path d="M 860 700 V 380 M 940 700 V 380" />
      {[430, 490, 550, 610, 670].map((yy) => <line key={yy} x1={860} y1={yy} x2={940} y2={yy} />)}
    </g>
    {/* stone circle */}
    <ellipse cx={960} cy={880} rx={640} ry={140} fill="#8F8C86" stroke={INK} strokeWidth={5} />
    <ellipse cx={960} cy={880} rx={600} ry={118} fill="#9C9993" />
  </g>
);

export const HRuins: React.FC<{ t: number }> = ({ t }) => (
  <g>
    <defs>
      <linearGradient id="hruinsky" x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#4A4450" />
        <stop offset="0.7" stopColor="#D9833F" />
        <stop offset="1" stopColor="#F2B368" />
      </linearGradient>
    </defs>
    <rect width={1920} height={1080} fill="url(#hruinsky)" />
    <rect y={780} width={1920} height={300} fill="#5C4E3E" />
    {[250, 700, 1250, 1680].map((bx, i) => (
      <g key={i}>
        <rect x={bx - 110} y={520 + (i % 2) * 40} width={220} height={260 - (i % 2) * 40} fill="#E6DFD0" stroke={INK} strokeWidth={5} />
        <path d={`M ${bx - 130} ${520 + (i % 2) * 40} L ${bx} ${430 + (i % 2) * 40} L ${bx + 130} ${520 + (i % 2) * 40} Z`} fill="#B5472E" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
        <rect x={bx - 28} y={650} width={56} height={130} fill="#3A2A1E" />
        <HFlame x={bx - 60} y={520 + (i % 2) * 40} s={1.1} t={t} seed={i} />
        <HFlame x={bx + 50} y={540 + (i % 2) * 40} s={0.8} t={t} seed={i + 5} />
        <HSmoke x={bx} y={430 + (i % 2) * 40} s={1.2} t={t + i * 11} n={4} />
      </g>
    ))}
  </g>
);
