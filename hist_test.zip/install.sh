#!/bin/sh
# Installs the HIST test pack (ancient-war comedy kit + test scene Hist00) into /workspace/studio. Safe to run twice.
set -e
S=/workspace/studio
[ -d "$S/src/episodes" ] || { echo "can't find $S/src/episodes"; exit 1; }
rm -rf "$S/src/episodes/hist"
mkdir -p "$S/src/episodes/hist" "$S/public/hist"
cp engine/cast.tsx engine/hist.tsx "$S/src/engine/"
cp episode/index.tsx episode/shots.tsx episode/timelines.json "$S/src/episodes/hist/"
cp voice/silence.mp3 "$S/public/hist/"
# the contact-sheet workflow reads timelines from episodes/vet/timelines.json, so put a copy there too (harmless: no code lives there)
mkdir -p "$S/src/episodes/vet"
cp episode/timelines.json "$S/src/episodes/vet/timelines.json"
ENG="$S/src/engine/index.ts"
for m in cast hist; do grep -q "from './$m'" "$ENG" || echo "export * from './$m';" >> "$ENG"; done
IDX="$S/src/episodes/index.ts"
grep -q "from './hist'" "$IDX" || sed -i "1i import { histEpisodes } from './hist';" "$IDX"
grep -q "EPISODES = \[.*histEpisodes" "$IDX" || sed -i "s/EPISODES = \[/EPISODES = [...histEpisodes, /" "$IDX"
echo "--- $IDX:"; cat "$IDX"
echo "OK: HIST test pack installed."
