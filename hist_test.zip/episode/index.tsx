import { defineEpisode, Timeline } from '../../engine';
import { T1, T2, T3, T4 } from './shots';
import tls from './timelines.json';

// "HIST" test scene: Hist00. Ancient-war comedy pack only.
const SHOTS = { T1, T2, T3, T4 };
export const histEpisodes = Object.entries(tls).map(([id, tl]) => defineEpisode(id, { timeline: tl as unknown as Timeline, shots: SHOTS }));
