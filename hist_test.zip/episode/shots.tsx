import React from 'react';
import { ShotProps, camT, kf } from '../../engine';
import { HLOOKS, Hist, histPose, HCamp, HRuins, HBoard, HCaption, HFireball, HPuddle, HSword, HTorch, HSmoke, HFlame, HAcc } from '../../engine';

// Test scene for the HIST pack: 4 shots, 11 seconds. Original jokes, original characters.
const GD = 900;

const General: HAcc = { helm: 'crest', beard: true, patch: 'l' };
const Officer: HAcc = { helm: 'crest', helmColor: '#B9A247', brows: 'angry' };
const Soldier: HAcc = { helm: 'pointed' };

const Cam: React.FC<{ t: number; len: number; z?: [number, number]; cx?: [number, number]; children: React.ReactNode }> = ({ t, len, z = [1, 1.06], cx = [960, 960], children }) => (
  <g transform={camT(kf(t, [[0, cx[0]], [len, cx[1]]]), 540, kf(t, [[0, z[0]], [len, z[1]]]))}>{children}</g>
);

// 1) The general at his ideas board: the red X lands on the plan he just proposed.
export const T1: React.FC<ShotProps> = ({ t, len }) => (
  <g>
    <Cam t={t} len={len} z={[1, 1.08]} cx={[900, 960]}>
      <HCamp variant={1} />
      <HBoard x={260} y={230} w={700} h={420} t={t} title="PLAN BOARD" ground={880} items={[
        { text: 'CHARGE THE GATE?', mark: 'x', at: 12 },
        { text: 'BUILD A LADDER' },
        { text: 'TAKE A NAP', mark: 'check', at: 24 },
      ]} />
      <Hist pose={histPose('idle', t, { x: 1640, ground: 840, scale: 1.15, facing: -1 })} look={HLOOKS.puni} acc={Soldier} t={t} />
      <Hist pose={histPose('draw', t, { x: 1250, ground: GD, scale: 1.5, facing: -1 })} look={HLOOKS.captain} acc={General} t={t} />
    </Cam>
    <HCaption t={t} y={160} words={[['Charge', 2], ['the', 6], ['gate?', 9], ['Nope.', 20]]} tick={{ x: 1190, y: 330 }} />
  </g>
);

// 2) The officer explodes; the general freezes.
export const T2: React.FC<ShotProps> = ({ t, len }) => (
  <g>
    <Cam t={t} len={len} z={[1, 1.1]} cx={[960, 940]}>
      <HCamp variant={2} />
      <Hist pose={histPose('idle', t, { x: 1560, ground: 850, scale: 1.15, facing: -1 })} look={HLOOKS.puni} acc={Soldier} t={t} />
      <Hist pose={histPose('point', t, { x: 640, ground: GD, scale: 1.5, facing: 1, side: 'right', expr: 'neutral' })} look={HLOOKS.captain} acc={{ ...Officer, mouth: 'shout' }} t={t} />
      <Hist pose={histPose(t < 24 ? 'idle' : 'shock', t < 24 ? t : t - 24, { x: 1200, ground: GD, scale: 1.5, facing: -1 })} look={HLOOKS.captain} acc={General} t={t} />
    </Cam>
    <HCaption t={t} y={150} words={[['That', 2], ['is', 6], ['the', 9], ['WORST', 12], ['plan', 18], ['EVER!', 24]]} tick={{ x: 600, y: 330 }} />
  </g>
);

// 3) The whole ring of soldiers reacts at once ("ooh"), swords at their sides.
const RING: [number, number, number][] = [
  [300, 780, 1.0], [560, 790, 1.0], [820, 800, 1.0], [1100, 800, 1.0], [1360, 790, 1.0], [1620, 780, 1.0],
  [430, 900, 1.2], [960, 920, 1.25], [1490, 900, 1.2],
];
export const T3: React.FC<ShotProps> = ({ t, len }) => (
  <g>
    <Cam t={t} len={len} z={[1.08, 1]} cx={[960, 960]}>
      <HCamp variant={1} />
      {RING.map(([x, g, s], i) => {
        const d = (i * 3) % 7;
        const ooh = t >= 8 + d;
        return (
          <g key={i}>
            <Hist pose={histPose(ooh ? 'shock' : 'idle', Math.max(0, t - 8 - d), { x, ground: g, scale: s * 1.1 })} look={i % 3 === 0 ? HLOOKS.legion : HLOOKS.puni} acc={{ helm: i % 3 === 0 ? 'plume' : 'pointed', mouth: ooh ? 'ooh' : undefined }} t={t} shadow={0.3} />
            {i % 2 === 0 ? <HSword x={x + 62 * s * 1.1} y={g - 118 * s} s={0.5 * s} rot={4} /> : null}
          </g>
        );
      })}
    </Cam>
  </g>
);

// 4) Aftermath: burning town, a runner with a torch, a fallen soldier, a cartoon fireball.
export const T4: React.FC<ShotProps> = ({ t, len }) => (
  <g>
    <Cam t={t} len={len} z={[1, 1.05]} cx={[960, 1000]}>
      <HRuins t={t} />
      <HPuddle x={520} y={GD + 10} s={1.1} t={t} d={2} />
      <Hist pose={histPose('lie', t, { x: 520, ground: GD, scale: 1.3, facing: 1 })} look={HLOOKS.legion} acc={{ helm: 'plume', hurt: false }} t={t} />
      <Hist pose={histPose('torch', t, { x: 200, ground: 880, scale: 1.2, facing: 1, speed: 5 })} look={HLOOKS.puni} acc={Soldier} t={t} />
      <Hist pose={histPose('triumph', t, { x: 1500, ground: GD, scale: 1.5, facing: -1 })} look={HLOOKS.captain} acc={General} t={t} />
      <HFireball x={1180} y={620} s={1.4} t={t} d={4} />
      <HSmoke x={1180} y={560} s={1.5} t={t - 30} n={5} />
    </Cam>
  </g>
);
