#!/bin/sh
# Installs the Dossier kit (bigger version) + the Cast kit and the CastDemo episode into /workspace/studio. Safe to run twice.
set -e
S=/workspace/studio
[ -d "$S/src/episodes" ] || { echo "can't find $S/src/episodes"; exit 1; }
mkdir -p "$S/src/episodes/cast"
cp engine/dossier.tsx "$S/src/engine/dossier.tsx"
cp engine/cast.tsx "$S/src/engine/cast.tsx"
cp episode/shots.tsx episode/index.tsx episode/timeline.json "$S/src/episodes/cast/"
ENG="$S/src/engine/index.ts"
grep -q "from './dossier'" "$ENG" || echo "export * from './dossier';" >> "$ENG"
grep -q "from './cast'" "$ENG" || echo "export * from './cast';" >> "$ENG"
IDX="$S/src/episodes/index.ts"
grep -q "from './cast'" "$IDX" || sed -i "1i import { castDemo } from './cast';" "$IDX"
grep -q "EPISODES = \[.*castDemo" "$IDX" || sed -i "s/EPISODES = \[/EPISODES = [castDemo, /" "$IDX"
echo "--- $IDX:"; cat "$IDX"
echo "OK: Dossier + Cast kits installed."
