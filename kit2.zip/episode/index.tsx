import { defineEpisode, Timeline } from '../../engine';
import timeline from './timeline.json';
import { S1, S2, S3, S4, S5, S6, S7, S8 } from './shots';

// "CastDemo": 8 shots, about 16 s, no voice. A test of the Cast kit.
export const castDemo = defineEpisode('CastDemo', {
  timeline: timeline as Timeline,
  shots: { S1, S2, S3, S4, S5, S6, S7, S8 },
});
