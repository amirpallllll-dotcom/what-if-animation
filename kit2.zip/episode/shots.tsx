import React from 'react';
import { ShotProps, camT, kf, Chip, MarkPop, DuskHills, ChalkBoard, DeskTop, PunchWord, Person, Crowd, actionPose, CAST, FONT } from '../../engine';

// "CastDemo": a 16 second test of the Cast kit: walk, salute, point, a crowd that flips mood, bow, shrug and think, run, wave.
const G = 830;

// S1: a soldier walks across the hill
export const S1: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(kf(t, [[0, 700], [len, 1060]]), 540, 1.15)}>
    <DuskHills t={t} id="c1" />
    <Person pose={actionPose('walk', t, { x: 300, ground: G, scale: 0.9, speed: 9, facing: 1 })} look={CAST.soldier} gear="cap" />
  </g>
);

// S2: three of them salute, one after another
export const S2: React.FC<ShotProps> = ({ t }) => (
  <g>
    <DuskHills t={t} id="c2" sunX={960} />
    <Person pose={actionPose('salute', t - 4, { x: 560, ground: G, scale: 0.9 })} look={CAST.soldier} gear="cap" />
    <Person pose={actionPose('salute', t - 10, { x: 960, ground: G, scale: 0.9 })} look={CAST.officer} gear="cap" gearColor="#2F3E5C" />
    <Person pose={actionPose('salute', t - 16, { x: 1360, ground: G, scale: 0.9 })} look={CAST.soldier} gear="cap" />
  </g>
);

// S3: the officer points at the board
export const S3: React.FC<ShotProps> = ({ t }) => (
  <g>
    <ChalkBoard />
    <text x={1080} y={430} textAnchor="middle" fontFamily={FONT.hand} fontWeight={700} fontSize={110} fill="#F4F0E4" opacity={0.92}>
      The plan
    </text>
    <Person pose={actionPose('point', t - 6, { x: 520, ground: 1000, scale: 1.0, side: 'right' })} look={CAST.officer} gear="cap" gearColor="#2F3E5C" />
    <Chip x={1180} y={640} t={t} d={14} text="BRIEFING" />
  </g>
);

// S4: a crowd cheers, then freezes in shock, then sags
export const S4: React.FC<ShotProps> = ({ t }) => (
  <g>
    <DuskHills t={t} id="c4" sunX={960} sunY={520} />
    <Crowd t={t} x={960} ground={930} count={8} gap={230} scale={0.75} rows={2} moods={[{ f: 0, action: 'cheer' }, { f: 44, action: 'shock' }, { f: 70, action: 'sad' }]} />
  </g>
);

// S5: an elder bows to a child who waves
export const S5: React.FC<ShotProps> = ({ t }) => (
  <g>
    <DuskHills t={t} id="c5" sunX={1400} />
    <Person pose={actionPose('bow', t - 4, { x: 620, ground: G, scale: 0.95, facing: 1, hold: 16 })} look={CAST.elder} gear="none" />
    <Person pose={actionPose('wave', t, { x: 1180, ground: G, scale: 0.6, facing: -1 })} look={CAST.kid} gear="beanie" />
  </g>
);

// S6: a woman shrugs, then thinks
export const S6: React.FC<ShotProps> = ({ t }) => (
  <g>
    <DeskTop />
    <rect x={0} y={0} width={1920} height={1080} fill="#2A3A4A" opacity={0.0} />
    <Person pose={actionPose(t < 30 ? 'shrug' : 'think', t < 30 ? t : t - 30, { x: 960, ground: 1010, scale: 1.15 })} look={CAST.aunt} gear="scarf" gearColor="#4E6E8A" />
    <MarkPop x={1090} y={300} t={t} d={34} mark="?" />
  </g>
);

// S7: a worker runs across
export const S7: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(kf(t, [[0, 700], [len, 1100]]), 540, 1.1)}>
    <DuskHills t={t} id="c7" />
    <Person pose={actionPose('run', t, { x: 240, ground: G, scale: 0.9, speed: 17, facing: 1 })} look={CAST.worker} gear="beanie" />
  </g>
);

// S8: the pilot waves
export const S8: React.FC<ShotProps> = ({ t }) => (
  <g>
    <DuskHills t={t} id="c8" sunX={500} />
    <Person pose={actionPose('wave', t, { x: 1050, ground: G, scale: 1.05 })} look={CAST.pilot} gear="pilot" />
    <Chip x={160} y={110} t={t} d={4} text="READY" />
    <PunchWord x={620} y={300} t={t} d={14} text="GO!" color="#FFD54A" size={170} />
  </g>
);
