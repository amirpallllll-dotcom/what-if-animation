import React from 'react';
import { clamp, backOut, easeOut, easeInOut, lerp, settle } from './anim';
import { FONT } from './fonts';

// The DOSSIER kit: the paper-and-stamp "file" look. Cream cards, red rubber stamps, checklists that tick, route maps that
// draw themselves, flowcharts that pop in, counters, gauges, banners. Every piece is a pure function of the shot clock t
// (frames), with `d` = the frame it appears at. Nothing here knows the topic: swap the words and the same kit tells any
// story (a war, a prayer routine, a product, a science fact). World is 1920 x 1080.

export const DOS = {
  paper: '#F1E6CC',
  paperDark: '#D8C7A0',
  paperLine: '#B9A57A',
  ink: '#2B2622',
  red: '#C8402F',
  redDark: '#8E2A1E',
  green: '#4E8F4A',
  orange: '#E8963A',
  sea: '#6FA3A8',
  seaDark: '#5A8E94',
  land: '#B5BE86',
  landDark: '#8F9A63',
  wood: '#7A5A3C',
  woodDark: '#5E432B',
  mat: '#4F6B4A',
  board: '#2F4A3E',
};

const pop = (t: number, d: number, n = 7) => (t < d ? 0 : backOut(clamp((t - d) / n)));

/** A paper card with a coloured header strip. Children are drawn with their origin at the card's top-left corner. */
export const Card: React.FC<{ x: number; y: number; w: number; h: number; t: number; d?: number; title?: string; rot?: number; strip?: string; zoom?: number; children?: React.ReactNode }> = ({
  x, y, w, h, t, d = 0, title, rot = 0, strip = DOS.red, zoom = 1, children,
}) => {
  const s = pop(t, d);
  if (s <= 0) return null;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s * zoom})`}>
      <rect x={-w / 2 + 8} y={-h / 2 + 12} width={w} height={h} rx={14} fill="#000" opacity={0.28} />
      <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={14} fill={DOS.paper} stroke={DOS.ink} strokeWidth={5} />
      {title ? (
        <g>
          <path d={`M ${-w / 2} ${-h / 2 + 56} L ${-w / 2} ${-h / 2 + 14} Q ${-w / 2} ${-h / 2} ${-w / 2 + 14} ${-h / 2} L ${w / 2 - 14} ${-h / 2} Q ${w / 2} ${-h / 2} ${w / 2} ${-h / 2 + 14} L ${w / 2} ${-h / 2 + 56} Z`} fill={strip} stroke={DOS.ink} strokeWidth={5} />
          <text x={-w / 2 + 26} y={-h / 2 + 38} fontFamily={FONT.ui} fontSize={28} letterSpacing={5} fill={DOS.paper}>
            {title}
          </text>
        </g>
      ) : null}
      <g transform={`translate(${-w / 2} ${-h / 2})`}>{children}</g>
    </g>
  );
};

const burst = (r1: number, r2: number, n = 14) =>
  Array.from({ length: n * 2 }, (_, i) => {
    const a = (i / (n * 2)) * Math.PI * 2;
    const r = i % 2 ? r1 : r2;
    return `${(Math.cos(a) * r).toFixed(1)},${(Math.sin(a) * r).toFixed(1)}`;
  }).join(' ');

/** A rubber stamp that slams down at frame d: big and fast, lands with a jolt and a starburst. */
export const Stamp: React.FC<{ x: number; y: number; t: number; d?: number; text: string; color?: string; rot?: number; size?: number }> = ({
  x, y, t, d = 0, text, color = DOS.red, rot = -8, size = 64,
}) => {
  const k = t - d;
  if (k < 0) return null;
  const s = k < 4 ? 2.6 - 1.6 * easeOut(k / 4) : 1 + settle(k - 4, 0.07, 1.6, 6);
  const w = text.length * size * 0.62 + 44;
  const h = size + 40;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot})`}>
      {k >= 3 && k < 12 ? <polygon points={burst(w * 0.42 * (0.6 + (k - 3) / 12), w * 0.62 * (0.6 + (k - 3) / 12))} fill="#FFE27A" opacity={0.7 * (1 - (k - 3) / 9)} /> : null}
      <g transform={`scale(${s})`} opacity={clamp(k / 2)}>
        <rect x={-w / 2} y={-h / 2} width={w} height={h} rx={10} fill="none" stroke={color} strokeWidth={9} />
        <rect x={-w / 2 + 9} y={-h / 2 + 9} width={w - 18} height={h - 18} rx={5} fill="none" stroke={color} strokeWidth={3} />
        <text y={size * 0.34} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={size} letterSpacing={5} fill={color}>
          {text}
        </text>
      </g>
    </g>
  );
};

export type CheckItem = { text: string; at: number; mark?: 'tick' | 'cross' | 'open'; markAt?: number };

/** A checklist card: rows pop in at `at`, then a tick or cross draws on at `markAt` (the gamified "mission" card). */
export const Checklist: React.FC<{ x: number; y: number; t: number; d?: number; title: string; items: CheckItem[]; w?: number; zoom?: number }> = ({ x, y, t, d = 0, title, items, w = 470, zoom = 1.7 }) => {
  const rowH = 78;
  const h = 100 + items.length * rowH;
  return (
    <Card x={x} y={y} w={w} h={h} t={t} d={d} title={title} zoom={zoom}>
      {items.map((it, i) => {
        const s = pop(t, it.at, 6);
        const m = clamp((t - (it.markAt ?? it.at + 8)) / 5);
        const ry = 92 + i * rowH;
        return (
          <g key={i} transform={`translate(0 ${ry})`} opacity={clamp(s)}>
            <rect x={26} y={-30} width={52} height={52} rx={8} fill="#FFF8E6" stroke={DOS.ink} strokeWidth={5} />
            {it.mark === 'tick' && m > 0 ? <path d="M 34 -6 L 48 10 L 74 -26" stroke={DOS.green} strokeWidth={11} fill="none" strokeLinecap="round" strokeLinejoin="round" strokeDasharray={90} strokeDashoffset={90 * (1 - m)} /> : null}
            {it.mark === 'cross' && m > 0 ? <path d="M 36 -22 L 70 14 M 70 -22 L 36 14" stroke={DOS.red} strokeWidth={11} strokeLinecap="round" strokeDasharray={120} strokeDashoffset={120 * (1 - m)} /> : null}
            <text x={100} y={10} fontFamily={FONT.title} fontWeight={700} fontSize={34} letterSpacing={2} fill={DOS.ink}>
              {it.text}
            </text>
          </g>
        );
      })}
    </Card>
  );
};

/** A small chip with a year, a place or a count ("APR 1945"), usually in a corner. */
export const Chip: React.FC<{ x: number; y: number; t: number; d?: number; text: string; color?: string; zoom?: number }> = ({ x, y, t, d = 0, text, color = DOS.paper, zoom = 1.5 }) => {
  const s = pop(t, d, 6);
  if (s <= 0) return null;
  const w = text.length * 25 + 50;
  return (
    <g transform={`translate(${x} ${y}) scale(${s * zoom})`}>
      <rect x={0} y={-36} width={w} height={72} rx={14} fill={color} stroke={DOS.ink} strokeWidth={5} />
      <text x={w / 2} y={12} textAnchor="middle" fontFamily={FONT.ui} fontSize={36} letterSpacing={3} fill={DOS.ink}>
        {text}
      </text>
    </g>
  );
};

export type LogCard = { n: string; stamp?: string; stampAt?: number; activeAt?: number; blank?: boolean };

/** A row of numbered log cards (sortie 1, 2, 3): each can get a slanted stamp, and one lights up as the active card. */
export const CardRow: React.FC<{ x: number; y: number; t: number; d?: number; title: string; cards: LogCard[]; zoom?: number }> = ({ x, y, t, d = 0, title, cards, zoom = 1.7 }) => {
  const cw = 230;
  const gap = 26;
  const w = cards.length * cw + (cards.length + 1) * gap;
  const h = 420;
  return (
    <Card x={x} y={y} w={w} h={h} t={t} d={d} title={title} zoom={zoom}>
      {cards.map((c, i) => {
        const cx = gap + i * (cw + gap);
        const active = c.activeAt !== undefined && t >= c.activeAt;
        return (
          <g key={i} transform={`translate(${cx} 92)`}>
            <rect width={cw} height={300} rx={12} fill={c.blank ? '#C9BC9D' : '#FFF8E6'} stroke={active ? DOS.orange : DOS.ink} strokeWidth={active ? 10 : 5} />
            <text x={cw / 2} y={190} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={170} fill={c.blank ? '#A99C7E' : DOS.ink}>
              {c.n}
            </text>
            {c.stamp ? <Stamp x={cw / 2} y={220} t={t} d={c.stampAt ?? 0} text={c.stamp} size={34} rot={-12} /> : null}
          </g>
        );
      })}
    </Card>
  );
};

export type FlowNode = { id: string; text: string; x: number; y: number; at: number; w?: number; h?: number; style?: 'normal' | 'hot' | 'dashed' | 'dim' };
export type FlowArrow = { from: string; to: string; at: number; dur?: number; color?: string; dashed?: boolean };

const edge = (cx: number, cy: number, w: number, h: number, dx: number, dy: number) => {
  const k = 1 / Math.max(Math.abs(dx) / (w / 2), Math.abs(dy) / (h / 2), 1e-6);
  return { x: cx + dx * k, y: cy + dy * k };
};

/** A flowchart on a cream sheet: boxes pop in one by one, arrows draw between them (a "decision chart"). */
export const Flowchart: React.FC<{ t: number; d?: number; title?: string; nodes: FlowNode[]; arrows: FlowArrow[]; x?: number; y?: number; w?: number; h?: number }> = ({
  t, d = 0, title = 'DECISION CHART', nodes, arrows, x = 960, y = 540, w = 1500, h = 700,
}) => {
  const by: Record<string, FlowNode & { w: number; h: number }> = {};
  nodes.forEach((n) => (by[n.id] = { ...n, w: n.w ?? 300, h: n.h ?? 100 }));
  return (
    <Card x={x} y={y} w={w} h={h} t={t} d={d} title={title}>
      <g transform={`translate(${-(x - w / 2)} ${-(y - h / 2)})`}>
        {arrows.map((a, i) => {
          const A = by[a.from];
          const B = by[a.to];
          if (!A || !B) return null;
          const p = easeOut(clamp((t - a.at) / (a.dur ?? 10)));
          if (p <= 0) return null;
          const dx = B.x - A.x;
          const dy = B.y - A.y;
          const s0 = edge(A.x, A.y, A.w + 16, A.h + 16, dx, dy);
          const s1 = edge(B.x, B.y, B.w + 16, B.h + 16, -dx, -dy);
          const ex = lerp(s0.x, s1.x, p);
          const ey = lerp(s0.y, s1.y, p);
          const ang = (Math.atan2(s1.y - s0.y, s1.x - s0.x) * 180) / Math.PI;
          const col = a.color ?? DOS.ink;
          return (
            <g key={i}>
              <line x1={s0.x} y1={s0.y} x2={ex} y2={ey} stroke={col} strokeWidth={8} strokeLinecap="round" strokeDasharray={a.dashed ? '20 14' : undefined} />
              {p > 0.85 ? <path transform={`translate(${s1.x} ${s1.y}) rotate(${ang})`} d="M 0 0 L -28 -16 L -28 16 Z" fill={col} /> : null}
            </g>
          );
        })}
        {nodes.map((n) => {
          const N = by[n.id];
          const s = pop(t, n.at, 6);
          if (s <= 0) return null;
          const hot = n.style === 'hot';
          const dim = n.style === 'dim';
          return (
            <g key={n.id} transform={`translate(${N.x} ${N.y}) scale(${s})`} opacity={dim ? 0.55 : 1}>
              <rect x={-N.w / 2} y={-N.h / 2} width={N.w} height={N.h} rx={14} fill={hot ? '#F6C760' : '#FFF8E6'} stroke={hot ? DOS.orange : DOS.ink} strokeWidth={6} strokeDasharray={n.style === 'dashed' ? '16 10' : undefined} />
              <text y={12} textAnchor="middle" fontFamily={FONT.title} fontWeight={700} fontSize={N.h > 90 ? 34 : 28} letterSpacing={2} fill={DOS.ink}>
                {n.text}
              </text>
            </g>
          );
        })}
      </g>
    </Card>
  );
};

const partial = (pts: [number, number][], p: number): [number, number][] => {
  const seg = pts.slice(1).map((q, i) => Math.hypot(q[0] - pts[i][0], q[1] - pts[i][1]));
  const total = seg.reduce((a, b) => a + b, 0);
  let left = total * clamp(p);
  const out: [number, number][] = [pts[0]];
  for (let i = 0; i < seg.length; i++) {
    if (left >= seg[i]) {
      out.push(pts[i + 1]);
      left -= seg[i];
    } else {
      const k = left / seg[i];
      out.push([lerp(pts[i][0], pts[i + 1][0], k), lerp(pts[i][1], pts[i + 1][1], k)]);
      break;
    }
  }
  return out;
};

export type MapPin = { x: number; y: number; at: number; label?: string; kind?: 'dot' | 'base' | 'ship' | 'target' };
export type MapRoute = { pts: [number, number][]; at: number; dur?: number; color?: string; dashed?: boolean; endX?: boolean };

export const LAND_DEFAULT = [
  'M 120 420 Q 220 300 360 330 Q 470 360 520 470 Q 560 600 430 660 Q 280 700 170 620 Q 90 540 120 420 Z',
  'M 760 180 Q 900 120 1060 170 Q 1200 230 1150 340 Q 1080 420 930 400 Q 770 370 740 270 Q 730 220 760 180 Z',
  'M 1380 600 Q 1500 540 1640 590 Q 1760 650 1700 760 Q 1600 840 1470 800 Q 1350 740 1380 600 Z',
];

/** A sea map: land blobs, pins that pop with labels, and routes that draw themselves (a red X where a route ends). */
export const RouteMap: React.FC<{ t: number; land?: string[]; pins?: MapPin[]; routes?: MapRoute[]; tint?: string }> = ({ t, land = LAND_DEFAULT, pins = [], routes = [], tint = DOS.sea }) => (
  <g>
    <rect x={0} y={0} width={1920} height={1080} fill={tint} />
    {Array.from({ length: 26 }, (_, i) => (
      <path key={i} d={`M ${(i * 211) % 1800} ${(i * 137) % 1000 + 40} q 20 -14 40 0 t 40 0`} stroke="#fff" strokeWidth={4} fill="none" opacity={0.28} />
    ))}
    {land.map((p, i) => (
      <g key={i}>
        <path d={p} fill={DOS.landDark} transform="translate(0 14)" />
        <path d={p} fill={DOS.land} stroke={DOS.ink} strokeWidth={5} strokeLinejoin="round" />
      </g>
    ))}
    {routes.map((r, i) => {
      const p = clamp((t - r.at) / (r.dur ?? 24));
      if (p <= 0) return null;
      const pts = partial(r.pts, easeInOut(p));
      const col = r.color ?? DOS.red;
      const last = r.pts[r.pts.length - 1];
      return (
        <g key={i}>
          <polyline points={pts.map((q) => q.join(',')).join(' ')} fill="none" stroke={col} strokeWidth={11} strokeLinecap="round" strokeLinejoin="round" strokeDasharray={r.dashed ? '26 18' : undefined} />
          {r.endX && p >= 1 ? (
            <g transform={`translate(${last[0]} ${last[1]}) scale(${pop(t, r.at + (r.dur ?? 24), 5)})`}>
              <path d="M -26 -26 L 26 26 M 26 -26 L -26 26" stroke={DOS.red} strokeWidth={14} strokeLinecap="round" />
            </g>
          ) : null}
        </g>
      );
    })}
    {pins.map((p, i) => {
      const s = pop(t, p.at, 6);
      if (s <= 0) return null;
      return (
        <g key={i} transform={`translate(${p.x} ${p.y}) scale(${s})`}>
          {p.kind === 'ship' ? (
            <path d="M -36 0 L 36 0 L 24 22 L -24 22 Z M -10 0 L -10 -22 L 14 -22 L 14 0" fill="#7C838C" stroke={DOS.ink} strokeWidth={5} strokeLinejoin="round" />
          ) : p.kind === 'target' ? (
            <g fill="none" stroke={DOS.red} strokeWidth={8}>
              <circle r={34} />
              <circle r={14} />
            </g>
          ) : (
            <g>
              <path d="M 0 0 C -26 -34 -26 -64 0 -64 C 26 -64 26 -34 0 0 Z" fill={DOS.red} stroke={DOS.ink} strokeWidth={5} />
              <circle cy={-44} r={9} fill={DOS.paper} />
            </g>
          )}
          {p.label ? (
            <text y={p.kind === 'ship' ? 62 : 44} textAnchor="middle" fontFamily={FONT.ui} fontSize={30} letterSpacing={3} fill={DOS.ink} stroke={DOS.paper} strokeWidth={7} paintOrder="stroke">
              {p.label}
            </text>
          ) : null}
        </g>
      );
    })}
  </g>
);

/** A round analog gauge (fuel, speed, pressure): the needle sweeps from `from` to `to` (0..1) between frames at and at+dur. */
export const AnalogGauge: React.FC<{ x: number; y: number; t: number; d?: number; r?: number; from: number; to: number; at?: number; dur?: number; label?: string }> = ({
  x, y, t, d = 0, r = 300, from, to, at = 6, dur = 18, label = 'FUEL',
}) => {
  const s = pop(t, d, 8);
  if (s <= 0) return null;
  const v = from + (to - from) * easeInOut(clamp((t - at) / dur));
  const ang = -120 + v * 240;
  const pt = (a: number, rr: number) => `${(Math.sin((a * Math.PI) / 180) * rr).toFixed(1)} ${(-Math.cos((a * Math.PI) / 180) * rr).toFixed(1)}`;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <circle r={r + 24} fill="#2B2B2B" stroke={DOS.ink} strokeWidth={8} />
      <circle r={r} fill="#EFE7D2" stroke={DOS.ink} strokeWidth={6} />
      <path d={`M ${pt(-120, r * 0.82)} A ${r * 0.82} ${r * 0.82} 0 0 1 ${pt(-80, r * 0.82)}`} stroke={DOS.red} strokeWidth={22} fill="none" />
      {Array.from({ length: 13 }, (_, i) => {
        const a = -120 + i * 20;
        return <path key={i} d={`M ${pt(a, r * 0.86)} L ${pt(a, i % 3 === 0 ? r * 0.7 : r * 0.78)}`} stroke={DOS.ink} strokeWidth={i % 3 === 0 ? 9 : 5} />;
      })}
      <text y={r * 0.42} textAnchor="middle" fontFamily={FONT.ui} fontSize={r * 0.17} letterSpacing={6} fill={DOS.ink}>
        {label}
      </text>
      <text x={-r * 0.62} y={r * 0.62} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={r * 0.2} fill={DOS.red}>E</text>
      <text x={r * 0.62} y={r * 0.62} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={r * 0.2} fill={DOS.ink}>F</text>
      <g transform={`rotate(${ang})`}>
        <path d={`M -12 30 L 0 ${-r * 0.78} L 12 30 Z`} fill={DOS.red} stroke={DOS.ink} strokeWidth={4} strokeLinejoin="round" />
      </g>
      <circle r={26} fill={DOS.ink} />
    </g>
  );
};

/** A counter chip that counts from one number to another ("ISLANDS TAKEN x2"). */
export const CounterChip: React.FC<{ x: number; y: number; t: number; d?: number; label: string; from: number; to: number; at?: number; dur?: number; prefix?: string; suffix?: string; zoom?: number }> = ({
  x, y, t, d = 0, label, from, to, at = 8, dur = 20, prefix = '', suffix = '', zoom = 1.6,
}) => {
  const s = pop(t, d, 6);
  if (s <= 0) return null;
  const v = Math.round(lerp(from, to, easeOut(clamp((t - at) / dur))));
  const w = Math.max(label.length * 24 + 190, 380);
  const bump = t > at && t < at + dur ? 1 + 0.06 * Math.sin((t - at) * 0.9) : 1;
  return (
    <g transform={`translate(${x} ${y}) scale(${s * zoom})`}>
      <rect x={0} y={-46} width={w} height={92} rx={16} fill={DOS.paper} stroke={DOS.ink} strokeWidth={6} />
      <text x={24} y={12} fontFamily={FONT.ui} fontSize={32} letterSpacing={3} fill={DOS.ink}>
        {label}
      </text>
      <g transform={`translate(${w - 28} 0) scale(${bump})`}>
        <text textAnchor="end" y={22} fontFamily={FONT.title} fontWeight={800} fontSize={72} fill={DOS.red}>
          {prefix + v + suffix}
        </text>
      </g>
    </g>
  );
};

export type StatusRow = { label: string; from: number; to: number };

/** A status card with bars that fill or drain and a percent that counts (SUPPLY STATUS, MORALE, BATTERY). */
export const StatusCard: React.FC<{ x: number; y: number; t: number; d?: number; title: string; rows: StatusRow[]; at?: number; dur?: number; zoom?: number }> = ({ x, y, t, d = 0, title, rows, at = 10, dur = 26, zoom = 1.7 }) => {
  const w = 820;
  const h = 130 + rows.length * 120;
  const p = easeInOut(clamp((t - at) / dur));
  return (
    <Card x={x} y={y} w={w} h={h} t={t} d={d} title={title} zoom={zoom}>
      {rows.map((r, i) => {
        const v = lerp(r.from, r.to, p);
        return (
          <g key={i} transform={`translate(34 ${100 + i * 120})`}>
            <text y={26} fontFamily={FONT.ui} fontSize={30} letterSpacing={3} fill={DOS.ink}>
              {r.label}
            </text>
            <rect y={46} width={600} height={34} rx={17} fill="#CDBF9D" stroke={DOS.ink} strokeWidth={5} />
            <rect y={46} width={Math.max(4, 600 * v)} height={34} rx={17} fill={v < 0.35 ? DOS.red : DOS.green} stroke={DOS.ink} strokeWidth={5} />
            <text x={730} y={78} textAnchor="end" fontFamily={FONT.title} fontWeight={800} fontSize={54} fill={v < 0.35 ? DOS.red : DOS.ink}>
              {Math.round(v * 100)}%
            </text>
          </g>
        );
      })}
    </Card>
  );
};

/** A banner that drops in from above with a bounce (LOSING THE WAR, NAVY SPECIAL ATTACK). */
export const Ribbon: React.FC<{ x: number; y: number; t: number; d?: number; text: string; color?: string }> = ({ x, y, t, d = 0, text, color = DOS.red }) => {
  const k = t - d;
  if (k < 0) return null;
  const drop = (1 - backOut(clamp(k / 10))) * -420;
  const w = text.length * 40 + 140;
  return (
    <g transform={`translate(${x} ${y + drop})`}>
      <path d={`M ${-w / 2 - 60} -10 L ${-w / 2 + 10} -10 L ${-w / 2 + 10} 70 L ${-w / 2 - 60} 70 L ${-w / 2 - 30} 30 Z`} fill={DOS.redDark} stroke={DOS.ink} strokeWidth={5} strokeLinejoin="round" />
      <path d={`M ${w / 2 + 60} -10 L ${w / 2 - 10} -10 L ${w / 2 - 10} 70 L ${w / 2 + 60} 70 L ${w / 2 + 30} 30 Z`} fill={DOS.redDark} stroke={DOS.ink} strokeWidth={5} strokeLinejoin="round" />
      <rect x={-w / 2} y={-30} width={w} height={110} fill={color} stroke={DOS.ink} strokeWidth={6} />
      <text y={40} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={58} letterSpacing={6} fill={DOS.paper}>
        {text}
      </text>
    </g>
  );
};

/** A single big punch word that slams in with a pop and a small tilt (ALIVE., NO RETURN, WHY?). */
export const PunchWord: React.FC<{ x: number; y: number; t: number; d?: number; text: string; color?: string; size?: number; rot?: number }> = ({ x, y, t, d = 0, text, color = '#7CE05A', size = 150, rot = -3 }) => {
  const k = t - d;
  if (k < 0) return null;
  const s = k < 6 ? backOut(clamp(k / 6)) : 1 + settle(k - 6, 0.04, 1.4, 7);
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
      <text textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={size} fill={color} stroke="#14120F" strokeWidth={size * 0.12} paintOrder="stroke" strokeLinejoin="round" style={{ filter: 'drop-shadow(0 6px 0 rgba(0,0,0,0.35))' }}>
        {text}
      </text>
    </g>
  );
};

/** A "?" or "!" popping above a head (shock, doubt). */
export const MarkPop: React.FC<{ x: number; y: number; t: number; d?: number; mark?: '?' | '!' | '!?'; hold?: number }> = ({ x, y, t, d = 0, mark = '?', hold = 30 }) => {
  const k = t - d;
  if (k < 0 || k > hold + 6) return null;
  const s = k < hold ? backOut(clamp(k / 6)) : 1 - clamp((k - hold) / 6);
  return (
    <g transform={`translate(${x} ${y - 20}) rotate(${Math.sin(k * 0.5) * 6}) scale(${s})`}>
      <text textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={110} fill="#FFE27A" stroke="#14120F" strokeWidth={14} paintOrder="stroke">
        {mark}
      </text>
    </g>
  );
};

/** A scroll that unrolls from the middle with lines of text (an order, a rule, a list). Give it a unique id per shot. */
export const Scroll: React.FC<{ x: number; y: number; t: number; d?: number; w?: number; h?: number; lines: string[]; id?: string }> = ({ x, y, t, d = 0, w = 900, h = 420, lines, id = 'sc' }) => {
  const k = t - d;
  if (k < 0) return null;
  const open = easeOut(clamp(k / 14));
  const half = (w / 2) * open;
  return (
    <g transform={`translate(${x} ${y})`}>
      <clipPath id={`${id}-clip`}>
        <rect x={-half} y={-h / 2} width={half * 2} height={h} />
      </clipPath>
      <rect x={-half} y={-h / 2} width={half * 2} height={h} fill={DOS.paper} stroke={DOS.ink} strokeWidth={6} />
      <g clipPath={`url(#${id}-clip)`}>
        {lines.map((l, i) => (
          <text key={i} y={-h / 2 + 90 + i * 84} textAnchor="middle" fontFamily={FONT.title} fontWeight={i === 0 ? 800 : 700} fontSize={i === 0 ? 62 : 44} letterSpacing={i === 0 ? 8 : 4} fill={i === 0 ? DOS.red : DOS.ink}>
            {l}
          </text>
        ))}
      </g>
      {[-1, 1].map((sd) => (
        <g key={sd} transform={`translate(${sd * half} 0)`}>
          <rect x={-22} y={-h / 2 - 20} width={44} height={h + 40} rx={22} fill={DOS.wood} stroke={DOS.ink} strokeWidth={6} />
          <rect x={-22} y={-h / 2 - 20} width={16} height={h + 40} rx={8} fill={DOS.woodDark} opacity={0.4} />
        </g>
      ))}
    </g>
  );
};

/** A dusk landscape for outdoor beats: peach-to-purple sky, low sun, three layers of hills. */
export const DuskHills: React.FC<{ t: number; id?: string; sunX?: number; sunY?: number }> = ({ t, id = 'dh', sunX = 1300, sunY = 560 }) => (
  <g>
    <defs>
      <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#6C5A86" />
        <stop offset="0.55" stopColor="#E9A27F" />
        <stop offset="1" stopColor="#F6D3A0" />
      </linearGradient>
    </defs>
    <rect x={0} y={0} width={1920} height={1080} fill={`url(#${id}-sky)`} />
    <circle cx={sunX} cy={sunY} r={120} fill="#FFE7B3" opacity={0.9} />
    <circle cx={sunX} cy={sunY} r={190} fill="#FFE7B3" opacity={0.2 + 0.04 * Math.sin(t * 0.1)} />
    <path d="M 0 700 Q 300 560 620 660 Q 900 740 1200 620 Q 1560 500 1920 640 L 1920 1080 L 0 1080 Z" fill="#8D8A7B" />
    <path d="M 0 790 Q 340 680 700 770 Q 1040 850 1380 740 Q 1680 660 1920 760 L 1920 1080 L 0 1080 Z" fill="#7B8A62" />
    <path d="M 0 900 Q 400 830 800 890 Q 1200 950 1600 880 Q 1800 850 1920 880 L 1920 1080 L 0 1080 Z" fill="#5E7048" />
  </g>
);

/** A top-down wooden desk with a green mat, for card shots. */
export const DeskTop: React.FC<{ t?: number }> = () => (
  <g>
    <rect x={0} y={0} width={1920} height={1080} fill={DOS.wood} />
    {Array.from({ length: 14 }, (_, i) => (
      <path key={i} d={`M 0 ${i * 84 + 20} Q 480 ${i * 84 - 10} 960 ${i * 84 + 30} T 1920 ${i * 84 + 10}`} stroke={DOS.woodDark} strokeWidth={4} fill="none" opacity={0.35} />
    ))}
    <rect x={110} y={70} width={1700} height={940} rx={26} fill={DOS.mat} stroke="#2F4330" strokeWidth={10} />
  </g>
);

/** A classroom chalkboard with a wooden frame. */
export const ChalkBoard: React.FC<{ children?: React.ReactNode }> = ({ children }) => (
  <g>
    <rect x={0} y={0} width={1920} height={1080} fill="#B9A27A" />
    <rect x={160} y={110} width={1600} height={780} rx={12} fill={DOS.board} stroke={DOS.woodDark} strokeWidth={26} />
    <rect x={160} y={904} width={1600} height={26} fill={DOS.woodDark} />
    {children}
  </g>
);
