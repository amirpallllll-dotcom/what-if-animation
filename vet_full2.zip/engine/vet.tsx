import React from 'react';
import { clamp, backOut, easeOut, lerp } from './anim';
import { FONT } from './fonts';
import { Hero, Pose, Look, joints, toWorld } from './rig';
import { CAST } from './cast';
import { DOS, Card, Stamp } from './dossier';

// The VET pack (military niche). Props and people for war-history stories: case-file card with a portrait silhouette,
// medals, headstones, flags, night forest, helmets, banners, folders. Same flat look as the Dossier and Cast kits.
// Never import this from a non-military episode. World is 1920 x 1080; every piece is a pure function of the shot clock t.

const INK = '#14121C';
const pop = (t: number, d: number, n = 7) => (t < d ? 0 : backOut(clamp((t - d) / n)));

// ---------- people ----------
const skinOf = (look: Look, skin: string, shade: string): Look => ({ ...look, skin, skinShade: shade, hand: skin });
export const VLOOKS = {
  soldier: CAST.soldier,
  soldierDark: skinOf(CAST.soldier, '#8A5A3C', '#70452D'),
  enemy: { ...CAST.soldier, jacket: '#3A3F44', jacketShade: '#2C3034', limb: '#2C3034', accent: '#8C8C8C' } as Look,
  medic: { ...CAST.soldier, jacket: '#8A8F6A', jacketShade: '#70755A', accent: '#C8402F' } as Look,
  sailor: { ...CAST.officer, jacket: '#E8E4D8', jacketShade: '#CFC9B8', limb: '#E8E4D8', accent: '#2F3E5C' } as Look,
  sailorDark: skinOf({ ...CAST.officer, jacket: '#E8E4D8', jacketShade: '#CFC9B8', limb: '#E8E4D8', accent: '#2F3E5C' } as Look, '#8A5A3C', '#70452D'),
  officer: CAST.officer,
  pilot: CAST.pilot,
  civilian: CAST.worker,
  civilianDark: skinOf(CAST.worker, '#8A5A3C', '#70452D'),
  latino: skinOf(CAST.soldier, '#C98E68', '#B07A58'),
  civilianLight: CAST.worker,
  elder: CAST.elder,
  kid: CAST.kid,
  aunt: CAST.aunt,
  suit: skinOf({ ...CAST.officer, jacket: '#22252E', jacketShade: '#181A21', limb: '#22252E', accent: '#C8402F' } as Look, '#8A5A3C', '#70452D'),
};

export type HelmKind = 'ww1' | 'ww2' | 'sailor' | 'medic' | 'cap' | 'none';
/** A helmet or cap that follows the head (the Cast kit only has a soft cap). */
export const Helm: React.FC<{ pose: Pose; kind: HelmKind; color?: string }> = ({ pose, kind, color }) => {
  if (kind === 'none') return null;
  const hd = toWorld(pose, joints(pose).head);
  return (
    <g transform={`translate(${hd.x} ${hd.y}) rotate(${pose.tilt + pose.headTilt + pose.spin}) scale(${pose.scale})`}>
      {kind === 'ww1' ? (
        <g>
          <path d="M -78 -30 Q -74 -98 0 -100 Q 74 -98 78 -30 Q 0 -44 -78 -30 Z" fill={color ?? '#8A8F6A'} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -82 -30 Q 0 -46 82 -30 L 80 -22 Q 0 -38 -80 -22 Z" fill="#6E7352" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        </g>
      ) : null}
      {kind === 'ww2' ? (
        <g>
          <path d="M -66 -34 Q -66 -96 0 -98 Q 66 -96 66 -34 Z" fill={color ?? '#6B7348'} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -70 -36 Q 0 -26 70 -36 L 72 -28 Q 0 -16 -72 -28 Z" fill="#565D39" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
          <path d="M -50 -60 Q 0 -70 50 -60" stroke="#565D39" strokeWidth={4} fill="none" />
        </g>
      ) : null}
      {kind === 'sailor' ? (
        <g>
          <path d="M -62 -36 Q -58 -78 0 -80 Q 58 -78 62 -36 Z" fill="#F4F0E4" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -66 -36 Q 0 -28 66 -36 L 62 -26 Q 0 -16 -62 -26 Z" fill="#2F3E5C" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
        </g>
      ) : null}
      {kind === 'cap' ? (
        <g>
          <path d="M -62 -34 Q -62 -84 0 -86 Q 62 -84 62 -34 Z" fill={color ?? '#2F3E5C'} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -64 -36 Q 0 -24 80 -34 L 78 -26 Q 0 -14 -64 -28 Z" fill={INK} />
          <circle cx={0} cy={-60} r={9} fill="#E7C766" stroke={INK} strokeWidth={3} />
        </g>
      ) : null}
      {kind === 'medic' ? (
        <g>
          <path d="M -66 -34 Q -66 -96 0 -98 Q 66 -96 66 -34 Z" fill={color ?? '#8A8F6A'} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <circle cx={0} cy={-64} r={20} fill="#F4F0E4" stroke={INK} strokeWidth={3} />
          <path d="M -4 -76 H 4 V -68 H 12 V -60 H 4 V -52 H -4 V -60 H -12 V -68 H -4 Z" fill={DOS.red} />
        </g>
      ) : null}
    </g>
  );
};

// ---------- guns (stylised, flat; no gore) ----------
export const MuzzleFlash: React.FC<{ x: number; y: number; t: number; d?: number; s?: number }> = ({ x, y, t, d = 0, s = 1 }) => {
  const a = t - d;
  if (a < 0 || a >= 6) return null;
  const k = a < 2 ? 1 : 0.7;
  return (
    <g transform={`translate(${x} ${y}) scale(${s * k}) rotate(${a * 17})`}>
      <polygon points="36,0 14,5 25,21 6,12 0,30 -6,12 -25,21 -14,5 -36,0 -14,-5 -25,-21 -6,-12 0,-30 6,-12 25,-21 14,-5" fill="#FF7A1A" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <polygon points="20,0 8,3 14,12 3,7 0,17 -3,7 -14,12 -8,3 -20,0 -8,-3 -14,-12 -3,-7 0,-17 3,-7 14,-12 8,-3" fill="#FFD23F" />
      <circle r={5} fill="#FFF3C4" />
    </g>
  );
};
/** Local gun art: origin at the trigger hand, barrel toward +x. kind: rifle | mg */
export const Gun: React.FC<{ kind?: 'rifle' | 'mg'; flash?: boolean }> = ({ kind = 'rifle', flash = false }) => (
  <g>
    {kind === 'rifle' ? (
      <g>
        <path d="M -122 -18 L -36 -15 L -36 4 L -6 4 Q -12 14 -34 16 L -128 24 Z" fill="#A9743F" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
        <path d="M -122 -18 L -112 -17 L -117 23 L -128 24 Z" fill="#7C4F26" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
        <path d="M -6 4 L -6 11 Q -6 19 3 19 L 5 19 Q 12 19 12 12 L 12 4" fill="none" stroke={INK} strokeWidth={5} strokeLinecap="round" />
        <rect x={14} y={-2} width={68} height={12} rx={4} fill="#A9743F" stroke={INK} strokeWidth={6} />
        <rect x={14} y={-14} width={116} height={12} fill="#414855" stroke={INK} strokeWidth={6} />
        <path d="M 26 -9 L 112 -9" fill="none" stroke="#5D6678" strokeWidth={3} strokeLinecap="round" />
        <rect x={70} y={-17} width={10} height={30} fill="#333947" stroke={INK} strokeWidth={5} />
        <rect x={-36} y={-18} width={54} height={22} fill="#333947" stroke={INK} strokeWidth={6} />
        <polygon points="112,-13 122,-13 119,-25 115,-25" fill="#2A2F38" stroke={INK} strokeWidth={4} strokeLinejoin="round" />
      </g>
    ) : (
      <g>
        {/* bipod */}
        <path d="M 70 8 L 46 52 M 76 8 L 100 52" stroke={INK} strokeWidth={9} strokeLinecap="round" />
        <path d="M 70 8 L 46 52 M 76 8 L 100 52" stroke="#414855" strokeWidth={4} strokeLinecap="round" />
        <path d="M -104 -16 L -40 -14 L -40 12 L -112 22 Z" fill="#A9743F" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
        <rect x={-40} y={-24} width={96} height={34} rx={4} fill="#333947" stroke={INK} strokeWidth={6} />
        <rect x={56} y={-18} width={80} height={22} fill="#414855" stroke={INK} strokeWidth={6} />
        <rect x={136} y={-22} width={40} height={30} rx={4} fill="#2A2F38" stroke={INK} strokeWidth={5} />
        {[0, 1, 2, 3, 4].map((i) => (<line key={i} x1={146 + i * 6} y1={-18} x2={146 + i * 6} y2={4} stroke="#5D6678" strokeWidth={2.5} />))}
        <rect x={-10} y={10} width={30} height={34} rx={5} fill="#5B6140" stroke={INK} strokeWidth={5} />
        <path d="M -4 44 Q -20 70 0 74 Q 26 74 26 62" fill="none" stroke="#B8923A" strokeWidth={9} strokeLinecap="round" strokeDasharray="10 4" />
        <path d="M -26 -24 L -26 -34 L 10 -34 L 10 -24" fill="none" stroke={INK} strokeWidth={5} />
      </g>
    )}
    {flash ? <MuzzleFlash x={kind === 'rifle' ? 150 : 200} y={-8} t={0} s={1.1} /> : null}
  </g>
);

/** Where a gun sits for a person: at the back hand, pointing in the facing direction, steadied by the front hand. */
const GunOn: React.FC<{ pose: Pose; kind: 'rifle' | 'mg'; flash: boolean }> = ({ pose, kind, flash }) => {
  const j = joints(pose);
  const f = pose.facing;
  const back = f === 1 ? j.armL.end : j.armR.end;
  const front = f === 1 ? j.armR.end : j.armL.end;
  const bw = toWorld(pose, back);
  const fw = toWorld(pose, front);
  const ang = (Math.atan2(fw.y - bw.y, Math.abs(fw.x - bw.x)) * 180) / Math.PI * 0.5;
  return (
    <g transform={`translate(${bw.x} ${bw.y - 6 * pose.scale}) scale(${f * pose.scale * (kind === 'mg' ? 0.9 : 1)} ${pose.scale * (kind === 'mg' ? 0.9 : 1)}) rotate(${ang * f * f})`}>
      <Gun kind={kind} flash={flash} />
    </g>
  );
};

/** Slanted brows for the 'determined' face (drawn over the 'cool' face, which has none). */
const Brows: React.FC<{ pose: Pose; skin: string }> = ({ pose, skin }) => {
  const hd = toWorld(pose, joints(pose).head);
  const y = Math.min(1, Math.abs(pose.yaw));
  return (
    <g transform={`translate(${hd.x} ${hd.y}) rotate(${pose.tilt + pose.headTilt + pose.spin}) scale(${pose.scale})`}>
      <g transform={`translate(${pose.yaw * 30} 0) scale(${1 - 0.28 * y} 1)`}>
        <path d="M -38 -34 L -10 -18 M 10 -18 L 38 -34" stroke={INK} strokeWidth={8} strokeLinecap="round" fill="none" />
        <rect x={-22} y={20} width={44} height={22} rx={8} fill={skin} />
        <path d="M -11 31 L 11 31" stroke={INK} strokeWidth={5} strokeLinecap="round" />
      </g>
    </g>
  );
};

export type VetProps = { pose: Pose; look?: Look; helm?: HelmKind; helmColor?: string; shadow?: number; gun?: 'rifle' | 'mg'; fireT?: number; brows?: boolean };
export const Vet: React.FC<VetProps> = ({ pose, look = VLOOKS.soldier, helm = 'none', helmColor, shadow = 0.6, gun, fireT, brows }) => (
  <g>
    <Hero look={look} pose={pose} shadow={shadow} />
    {gun ? <GunOn pose={pose} kind={gun} flash={fireT !== undefined && fireT % 5 < 2} /> : null}
    <Helm pose={pose} kind={helm} color={helmColor} />
    {brows ? <Brows pose={pose} skin={look.skin} /> : null}
  </g>
);

// ---------- smoke, blast, torpedo, submarine, podium, pot ----------
export const Smoke: React.FC<{ x: number; y: number; t: number; d?: number; s?: number; n?: number; color?: string }> = ({ x, y, t, d = 0, s = 1, n = 6, color = '#8D919B' }) => {
  if (t < d) return null;
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      {Array.from({ length: n }).map((_, i) => {
        const life = 60;
        const a = ((t - d + i * (life / n)) % life) / life;
        const px = Math.sin(i * 2.3 + a * 3) * 34 + (i - n / 2) * 10;
        return <circle key={i} cx={px} cy={-a * 260} r={26 + a * 50 + (i % 3) * 8} fill={color} opacity={0.62 * (1 - a) * Math.min(1, a * 6)} stroke={INK} strokeWidth={0} />;
      })}
    </g>
  );
};
export const Blast: React.FC<{ x: number; y: number; t: number; d?: number; s?: number }> = ({ x, y, t, d = 0, s = 1 }) => {
  const a = t - d;
  if (a < 0 || a > 22) return null;
  const k = easeOut(clamp(a / 7));
  const fade = 1 - clamp((a - 8) / 14);
  const pts = (r1: number, r2: number) => Array.from({ length: 16 }).map((_, i) => { const r = i % 2 ? r1 : r2; const an = (i / 16) * Math.PI * 2; return `${Math.cos(an) * r},${Math.sin(an) * r}`; }).join(' ');
  return (
    <g transform={`translate(${x} ${y}) scale(${s * (0.4 + k)})`} opacity={fade}>
      <circle r={150} fill="#FFFFFF" opacity={0.5 * (1 - k)} />
      <polygon points={pts(110, 210)} fill="#FF7A1A" stroke={INK} strokeWidth={8} strokeLinejoin="round" />
      <polygon points={pts(70, 140)} fill="#FFD23F" />
      <circle r={48} fill="#FFF3C4" />
    </g>
  );
};
export const Torpedo: React.FC<{ x1: number; x2: number; y: number; t: number; d?: number; dur?: number; s?: number }> = ({ x1, x2, y, t, d = 0, dur = 40, s = 1 }) => {
  if (t < d) return null;
  const k = clamp((t - d) / dur);
  const x = x1 + (x2 - x1) * k;
  const dir = x2 >= x1 ? 1 : -1;
  return (
    <g>
      <line x1={x1} y1={y} x2={x - dir * 40 * s} y2={y} stroke="#F4F8FA" strokeWidth={8} strokeDasharray="22 14" opacity={0.8} />
      <g transform={`translate(${x} ${y}) scale(${dir * s} ${s})`}>
        <path d="M -60 -12 L 40 -12 Q 70 -12 70 0 Q 70 12 40 12 L -60 12 Z" fill="#5C6670" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
        <rect x={-60} y={-12} width={22} height={24} fill="#3E4650" stroke={INK} strokeWidth={5} />
        <path d="M -60 0 L -86 -22 L -86 22 Z" fill="#3E4650" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      </g>
    </g>
  );
};
export const Submarine: React.FC<{ x: number; y: number; s?: number; t?: number; facing?: 1 | -1 }> = ({ x, y, s = 1, t = 0, facing = 1 }) => (
  <g transform={`translate(${x} ${y + Math.sin(t * 0.08) * 6}) scale(${facing * s} ${s})`}>
    <path d="M -300 20 Q -300 -30 -240 -34 L 220 -34 Q 300 -30 310 20 Q 300 70 220 74 L -240 74 Q -300 70 -300 20 Z" fill="#3F4A52" stroke={INK} strokeWidth={8} strokeLinejoin="round" />
    <path d="M -250 -20 L 240 -20" stroke="#5C6A74" strokeWidth={6} />
    <path d="M -60 -34 L -40 -96 L 60 -96 L 80 -34 Z" fill="#3F4A52" stroke={INK} strokeWidth={8} strokeLinejoin="round" />
    <path d="M 20 -96 L 20 -140 L 70 -140" fill="none" stroke={INK} strokeWidth={9} strokeLinecap="round" />
    <circle cx={-10} cy={-66} r={9} fill="#9DB4C0" stroke={INK} strokeWidth={5} />
    <path d="M -300 20 L -350 -10 M -300 20 L -350 50" stroke={INK} strokeWidth={9} strokeLinecap="round" />
  </g>
);
export const Podium: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <path d="M -110 0 L -90 -230 L 90 -230 L 110 0 Z" fill="#7A5A3C" stroke={INK} strokeWidth={7} strokeLinejoin="round" />
    <path d="M -100 -224 L 100 -224 L 106 -196 L -106 -196 Z" fill="#5E432B" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <circle cx={0} cy={-120} r={34} fill="#E7C766" stroke={INK} strokeWidth={6} />
    <polygon points="0,-148 8,-126 30,-126 12,-112 18,-90 0,-103 -18,-90 -12,-112 -30,-126 -8,-126" fill={INK} opacity={0.75} />
    <path d="M 0 -230 L 0 -280" stroke={INK} strokeWidth={9} strokeLinecap="round" />
    <ellipse cx={0} cy={-290} rx={16} ry={20} fill="#414855" stroke={INK} strokeWidth={6} />
  </g>
);
export const StockPot: React.FC<{ x: number; y: number; t: number; s?: number }> = ({ x, y, t, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    {[0, 1, 2].map((i) => {
      const a = ((t * 0.7 + i * 20) % 60) / 60;
      return <path key={i} d={`M ${-40 + i * 40} ${-170 - a * 90} q 14 -22 0 -44`} stroke="#EEF2F5" strokeWidth={8} fill="none" strokeLinecap="round" opacity={0.7 * (1 - a)} />;
    })}
    <ellipse cx={0} cy={-150} rx={104} ry={18} fill="#2E3238" stroke={INK} strokeWidth={6} />
    <path d="M -104 -150 L -96 -10 Q -96 4 -80 4 L 80 4 Q 96 4 96 -10 L 104 -150 Q 0 -128 -104 -150 Z" fill="#8C95A0" stroke={INK} strokeWidth={7} strokeLinejoin="round" />
    <path d="M -80 -128 L -74 -20" stroke="#C7CFD6" strokeWidth={8} strokeLinecap="round" opacity={0.7} />
    <path d="M -104 -120 Q -142 -120 -140 -96 M 104 -120 Q 142 -120 140 -96" stroke={INK} strokeWidth={9} fill="none" strokeLinecap="round" />
    <path d="M 8 -160 L 60 -260" stroke="#A9743F" strokeWidth={12} strokeLinecap="round" />
  </g>
);

// ---------- new backgrounds ----------
export const ShipDeck: React.FC<{ t: number; id?: string }> = ({ t, id = 'deck' }) => (
  <g>
    <defs>
      <linearGradient id={`${id}-s`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#7C8FA3" />
        <stop offset="1" stopColor="#C9D3DA" />
      </linearGradient>
    </defs>
    <rect width={1920} height={1080} fill={`url(#${id}-s)`} />
    <rect y={560} width={1920} height={200} fill="#4C6E8C" />
    {[0, 1, 2, 3].map((i) => (
      <path key={i} d={`M ${-200 + ((t * 1.5 + i * 520) % 2300)} ${600 + i * 44} q 60 -14 120 0 t 120 0`} stroke="#DCE8F0" strokeWidth={5} fill="none" opacity={0.45} />
    ))}
    {/* bulkhead on the left with a round hatch */}
    <path d="M 0 0 L 560 0 L 560 800 L 0 800 Z" fill="#6B747C" stroke={INK} strokeWidth={0} />
    {[0, 1, 2, 3].map((i) => (<line key={i} x1={140 * i + 20} y1={0} x2={140 * i + 20} y2={800} stroke="#5A6269" strokeWidth={6} />))}
    <circle cx={290} cy={300} r={110} fill="#4C555C" stroke={INK} strokeWidth={9} />
    <circle cx={290} cy={300} r={80} fill="#8FB0C2" stroke={INK} strokeWidth={7} />
    <path d="M 220 270 Q 250 250 280 252" stroke="#E8F2F7" strokeWidth={9} strokeLinecap="round" fill="none" opacity={0.7} />
    {/* railing */}
    <path d="M 560 700 L 1920 700" stroke={INK} strokeWidth={14} />
    <path d="M 560 700 L 1920 700" stroke="#9BA4AC" strokeWidth={7} />
    {[0, 1, 2, 3, 4, 5, 6, 7].map((i) => (<line key={i} x1={640 + i * 190} y1={700} x2={640 + i * 190} y2={850} stroke={INK} strokeWidth={10} />))}
    {/* steel deck */}
    <rect y={850} width={1920} height={230} fill="#59636B" stroke={INK} strokeWidth={0} />
    <rect y={846} width={1920} height={10} fill="#2F363C" />
    {[0, 1, 2, 3, 4, 5, 6, 7, 8, 9].map((i) => (<line key={i} x1={i * 220 - 60} y1={856} x2={i * 220 - 160} y2={1080} stroke="#3F474E" strokeWidth={5} />))}
  </g>
);
export const Galley: React.FC = () => (
  <g>
    <rect width={1920} height={1080} fill="#E5DFC9" />
    {Array.from({ length: 10 }).map((_, r) => Array.from({ length: 17 }).map((_, c) => (<rect key={`${r}-${c}`} x={c * 120} y={r * 90} width={116} height={86} fill="#EFEADA" stroke="#CFC8AE" strokeWidth={3} />)))}
    <rect y={0} width={1920} height={110} fill="#8A929A" />
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <g key={i} transform={`translate(${160 + i * 300} 110)`}>
        <line x1={0} y1={0} x2={0} y2={46} stroke={INK} strokeWidth={6} />
        <ellipse cx={0} cy={86} rx={28} ry={40} fill="#B9C1C8" stroke={INK} strokeWidth={6} />
      </g>
    ))}
    <rect y={760} width={1920} height={40} fill="#9AA3AB" stroke={INK} strokeWidth={6} />
    <rect y={800} width={1920} height={280} fill="#6E777F" stroke={INK} strokeWidth={0} />
    {[0, 1, 2, 3, 4, 5, 6].map((i) => (<line key={i} x1={i * 300} y1={800} x2={i * 300} y2={1080} stroke="#565F66" strokeWidth={6} />))}
  </g>
);
// ---------- case file ----------
export const Silhouette: React.FC<{ x: number; y: number; s?: number; color?: string }> = ({ x, y, s = 1, color = '#4A4338' }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle cx={0} cy={-34} r={34} fill={color} />
    <path d="M -74 70 Q -74 8 0 8 Q 74 8 74 70 Z" fill={color} />
  </g>
);

export type FileLine = { k: string; v: string; at?: number };
/** The case-file card of one veteran: portrait silhouette, name, a few facts, and an optional rubber stamp. */
export const CaseFile: React.FC<{
  x: number; y: number; t: number; d?: number; name: string; lines: FileLine[]; stamp?: string; stampAt?: number; stampColor?: string; zoom?: number; rot?: number;
}> = ({ x, y, t, d = 0, name, lines, stamp, stampAt = 40, stampColor = DOS.red, zoom = 1.45, rot = -1.5 }) => {
  const w = 700;
  const h = 330;
  return (
    <g>
      <Card x={x} y={y} w={w} h={h} t={t} d={d} title="CASE FILE" zoom={zoom} rot={rot}>
        <rect x={28} y={88} width={170} height={200} rx={8} fill="#E8DCBC" stroke={DOS.ink} strokeWidth={4} />
        <Silhouette x={113} y={170} s={1.05} />
        <text x={226} y={126} fontFamily={FONT.title} fontWeight={800} fontSize={42} fill={DOS.ink} letterSpacing={1}>
          {name}
        </text>
        <line x1={226} y1={140} x2={w - 26} y2={140} stroke={DOS.paperLine} strokeWidth={3} />
        {lines.map((ln, i) => (
          <g key={i} opacity={clamp(pop(t, d + (ln.at ?? 10 + i * 6)))}>
            <text x={226} y={184 + i * 44} fontFamily={FONT.ui} fontSize={22} letterSpacing={2} fill={DOS.redDark}>
              {ln.k}
            </text>
            <text x={400} y={184 + i * 44} fontFamily={FONT.title} fontWeight={700} fontSize={28} fill={DOS.ink}>
              {ln.v}
            </text>
          </g>
        ))}
      </Card>
      {stamp ? <Stamp x={x + 160 * zoom} y={y + 70 * zoom} t={t} d={stampAt} text={stamp} color={stampColor} rot={-10} size={54 * zoom * 0.8} /> : null}
    </g>
  );
};

// ---------- medals, flags, graves ----------
export type MedalKind = 'croix' | 'moh' | 'navycross' | 'heart';
/** A medal hanging from its ribbon at (x,y) (the ribbon top). Swings after it drops in at frame d. */
export const Medal: React.FC<{ x: number; y: number; t: number; d?: number; kind?: MedalKind; scale?: number }> = ({ x, y, t, d = 0, kind = 'moh', scale = 1 }) => {
  const k = t - d;
  if (k < 0) return null;
  const drop = k < 10 ? -300 * (1 - easeOut(k / 10)) : 0;
  const sw = k < 10 ? 0 : Math.sin((k - 10) * 0.22) * 9 * Math.exp(-(k - 10) / 26);
  const rib = kind === 'croix' ? ['#2D4A9A', '#F4F0E4', '#C8402F'] : kind === 'moh' ? ['#3E6EC0', '#3E6EC0', '#3E6EC0'] : kind === 'navycross' ? ['#2F3E5C', '#F4F0E4', '#2F3E5C'] : ['#6A2D8A', '#F4F0E4', '#6A2D8A'];
  return (
    <g transform={`translate(${x} ${y + drop}) rotate(${sw}) scale(${scale})`}>
      <polygon points="-44,-170 44,-170 36,0 -36,0" fill={rib[1]} stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <polygon points="-44,-170 -15,-170 -12,0 -36,0" fill={rib[0]} />
      <polygon points="15,-170 44,-170 36,0 12,0" fill={rib[2]} />
      <polygon points="-44,-170 44,-170 36,0 -36,0" fill="none" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      {kind === 'moh' ? (
        <g transform="translate(0 60)">
          <polygon points={star(86, 46, 5)} fill="#E7C766" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <circle r={26} fill="#F4E3A3" stroke={INK} strokeWidth={4} />
          <polygon points={star(16, 8, 5)} fill="#E7C766" stroke={INK} strokeWidth={2} />
        </g>
      ) : kind === 'heart' ? (
        <g transform="translate(0 56)">
          <path d="M 0 52 C -80 -4 -40 -52 0 -18 C 40 -52 80 -4 0 52 Z" fill="#6A2D8A" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
        </g>
      ) : (
        <g transform="translate(0 56)">
          <path d="M -16 -50 H 16 V -16 H 50 V 16 H 16 V 56 H -16 V 16 H -50 V -16 H -16 Z" fill="#E7C766" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
          <circle r={14} fill="#F4E3A3" stroke={INK} strokeWidth={3} />
        </g>
      )}
    </g>
  );
};

const star = (R: number, r: number, n: number) =>
  Array.from({ length: n * 2 }, (_, i) => {
    const a = -Math.PI / 2 + (i / (n * 2)) * Math.PI * 2;
    const rr = i % 2 ? r : R;
    return `${(Math.cos(a) * rr).toFixed(1)},${(Math.sin(a) * rr).toFixed(1)}`;
  }).join(' ');

/** A stone grave marker standing on the ground at (x,y). Text appears at frame d. */
export const Headstone: React.FC<{ x: number; y: number; t: number; d?: number; name?: string; dates?: string; scale?: number; rise?: boolean }> = ({ x, y, t, d = 0, name, dates, scale = 1, rise = true }) => {
  const k = t - d;
  if (k < 0) return null;
  const up = rise ? 1 - easeOut(clamp(k / 12)) : 0;
  return (
    <g transform={`translate(${x} ${y + up * 240}) scale(${scale})`}>
      <ellipse cx={0} cy={4} rx={118} ry={16} fill="#000" opacity={0.28} />
      <path d="M -92 0 L -92 -200 Q -92 -290 0 -290 Q 92 -290 92 -200 L 92 0 Z" fill="#BDB8AC" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
      <path d="M 40 -280 Q 92 -270 92 -200 L 92 0 L 40 0 Z" fill="#A6A094" opacity={0.7} />
      {name
        ? name.split(' ').map((w, i, a) => (
            <text key={i} x={0} y={-188 + i * 34 - (a.length - 2) * 17} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={w.length > 8 ? 26 : 30} fill="#3A362E" opacity={clamp((k - 10) / 6)}>
              {w}
            </text>
          ))
        : null}
      {dates ? (
        <text x={0} y={-104} textAnchor="middle" fontFamily={FONT.ui} fontSize={22} letterSpacing={1} fill="#3A362E" opacity={clamp((k - 14) / 6)}>
          {dates}
        </text>
      ) : null}
      <path d="M 0 -246 V -222 M -12 -236 H 12" stroke="#3A362E" strokeWidth={5} strokeLinecap="round" />
    </g>
  );
};

/** A flag on a pole. The cloth waves by sin; nation 'us' draws stripes and a star field. */
export const Flag: React.FC<{ x: number; y: number; t: number; d?: number; w?: number; h?: number; pole?: number }> = ({ x, y, t, d = 0, w = 300, h = 190, pole = 520 }) => {
  const s = pop(t, d, 8);
  if (s <= 0) return null;
  const n = 13;
  const cw = w / 20;
  const cols = Array.from({ length: 20 }, (_, i) => i);
  const wave = (i: number) => Math.sin(t * 0.16 - i * 0.55) * 9 * (i / 20);
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`}>
      <rect x={-5} y={-12} width={10} height={pole} fill="#8D8A7B" stroke={INK} strokeWidth={4} />
      <circle cx={0} cy={-16} r={9} fill="#E7C766" stroke={INK} strokeWidth={3} />
      {cols.map((i) => (
        <g key={i} transform={`translate(${5 + i * cw} ${wave(i)})`}>
          {Array.from({ length: n }, (_, j) => (
            <rect key={j} x={0} y={j * (h / n)} width={cw + 1} height={h / n + 0.5} fill={j % 2 ? '#F4F0E4' : '#C8402F'} />
          ))}
          {i < 8 ? <rect x={0} y={0} width={cw + 1} height={h * 0.54} fill="#2F3E5C" /> : null}
          {i < 8 && i % 2 === 0
            ? [0, 1, 2, 3].map((j) => <circle key={j} cx={cw * 0.8} cy={14 + j * (h * 0.13)} r={3} fill="#F4F0E4" />)
            : null}
        </g>
      ))}
    </g>
  );
};

// ---------- scenery ----------
/** A night forest: dark sky, moon, three layers of pine silhouettes. */
export const NightForest: React.FC<{ t: number; id?: string; fog?: boolean }> = ({ t, id = 'nf', fog = true }) => {
  const tree = (cx: number, base: number, hgt: number, col: string, key: number) => (
    <g key={key}>
      <rect x={cx - 6} y={base - 20} width={12} height={30} fill={col} />
      {[0, 1, 2, 3].map((j) => (
        <polygon key={j} points={`${cx - (70 - j * 12)},${base - j * hgt * 0.22} ${cx},${base - hgt * (0.55 + j * 0.15)} ${cx + (70 - j * 12)},${base - j * hgt * 0.22}`} fill={col} />
      ))}
    </g>
  );
  return (
    <g>
      <defs>
        <linearGradient id={`${id}-sky`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stopColor="#0E1230" />
          <stop offset="0.7" stopColor="#2A3258" />
          <stop offset="1" stopColor="#46507A" />
        </linearGradient>
      </defs>
      <rect width={1920} height={1080} fill={`url(#${id}-sky)`} />
      <circle cx={1500} cy={230} r={86} fill="#F1EBD4" opacity={0.95} />
      <circle cx={1500} cy={230} r={150} fill="#F1EBD4" opacity={0.12 + 0.02 * Math.sin(t * 0.1)} />
      {Array.from({ length: 16 }, (_, i) => tree(60 + i * 128, 780, 380 + (i % 3) * 40, '#1A2038', i))}
      {Array.from({ length: 12 }, (_, i) => tree(120 + i * 170, 860, 480 + (i % 4) * 36, '#10142A', 50 + i))}
      <path d="M 0 900 Q 500 850 1000 900 Q 1500 950 1920 890 L 1920 1080 L 0 1080 Z" fill="#0B0E20" />
      {fog ? <rect x={0} y={760} width={1920} height={200} fill="#8E9AC0" opacity={0.1 + 0.03 * Math.sin(t * 0.07)} /> : null}
    </g>
  );
};

/** An empty hanging banner on the ground that fell: "no parade". */
export const Banner: React.FC<{ x: number; y: number; t: number; d?: number; text: string; fallen?: boolean }> = ({ x, y, t, d = 0, text, fallen = true }) => {
  const k = t - d;
  if (k < 0) return null;
  const drop = fallen ? clamp(k / 14) : 1;
  const rot = fallen ? lerp(-4, 14, easeOut(drop)) : 0;
  return (
    <g transform={`translate(${x} ${y - 360 * (1 - easeOut(drop))}) rotate(${rot})`}>
      <path d="M -380 -50 Q 0 -30 380 -50 L 380 50 Q 0 70 -380 50 Z" fill="#E8D9A8" stroke={INK} strokeWidth={6} />
      <text y={20} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={62} letterSpacing={6} fill={DOS.redDark}>
        {text}
      </text>
    </g>
  );
};

/** A case-file folder tab with a number, tilted. */
export const Folder: React.FC<{ x: number; y: number; t: number; d?: number; n: string; rot?: number; scale?: number }> = ({ x, y, t, d = 0, n, rot = 0, scale = 1 }) => {
  const s = pop(t, d, 6);
  if (s <= 0) return null;
  return (
    <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s * scale})`}>
      <rect x={-86} y={-110} width={172} height={220} rx={10} fill="#D9B86A" stroke={INK} strokeWidth={6} />
      <path d="M -86 -110 H -20 L -4 -134 H -60 Q -86 -134 -86 -110 Z" fill="#C9A456" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
      <text y={26} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={92} fill={DOS.ink}>
        {n}
      </text>
    </g>
  );
};

/** A plain stone desk-top backdrop for case files at night (the Dossier DeskTop is brown). */
export const WarRoom: React.FC<{ t?: number }> = () => (
  <g>
    <rect width={1920} height={1080} fill="#2B3A33" />
    <rect y={0} width={1920} height={1080} fill="#000" opacity={0.18} />
    <path d="M 0 0 H 1920" stroke="#1D2A24" strokeWidth={4} />
  </g>
);

// ---------- extra props ----------
export const SeaBG: React.FC<{ t: number; id?: string; dusk?: boolean }> = ({ t, id = 'sea', dusk = false }) => (
  <g>
    <defs>
      <linearGradient id={`${id}-s`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor={dusk ? '#4A4468' : '#6FA8D8'} />
        <stop offset="1" stopColor={dusk ? '#E9A27F' : '#CFE6F2'} />
      </linearGradient>
    </defs>
    <rect width={1920} height={1080} fill={`url(#${id}-s)`} />
    <rect y={620} width={1920} height={460} fill={dusk ? '#2E4A66' : '#3E7DA8'} />
    {[0, 1, 2, 3, 4, 5].map((i) => (
      <path key={i} d={`M ${-200 + ((t * 2 + i * 340) % 2300)} ${680 + i * 62} q 60 -18 120 0 t 120 0`} stroke="#E6F1F7" strokeWidth={5} fill="none" opacity={0.5} />
    ))}
  </g>
);
export const SkyBG: React.FC<{ t: number; id?: string }> = ({ t, id = 'sky' }) => (
  <g>
    <defs>
      <linearGradient id={`${id}-s`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#7FA6D6" />
        <stop offset="1" stopColor="#E7EEF2" />
      </linearGradient>
    </defs>
    <rect width={1920} height={1080} fill={`url(#${id}-s)`} />
    {[0, 1, 2, 3].map((i) => (
      <g key={i} transform={`translate(${((i * 600 - t * 2.2) % 2400 + 2400) % 2400 - 300} ${200 + i * 170})`} opacity={0.9}>
        <ellipse rx={150} ry={40} fill="#fff" />
        <ellipse cx={-70} cy={-20} rx={80} ry={34} fill="#fff" />
        <ellipse cx={60} cy={-26} rx={90} ry={38} fill="#fff" />
      </g>
    ))}
    <path d="M 0 900 Q 500 840 1000 900 Q 1500 960 1920 880 L 1920 1080 L 0 1080 Z" fill="#5E7048" />
  </g>
);
export const Ridge: React.FC<{ t: number; id?: string }> = ({ t, id = 'rg' }) => (
  <g>
    <DuskBase id={id} />
    <path d="M 0 1080 L 0 520 Q 300 480 560 400 L 760 330 L 900 560 L 1100 640 L 1500 700 L 1920 740 L 1920 1080 Z" fill="#6E6A58" stroke={INK} strokeWidth={5} />
    <path d="M 760 330 L 900 560 L 880 1080 L 700 1080 Z" fill="#57543F" opacity={0.7} />
    {[0, 1, 2].map((i) => <ellipse key={i} cx={420 + i * 160} cy={420 - i * 18 - ((t * 0.6) % 20)} rx={50} ry={22} fill="#555" opacity={0.18} />)}
  </g>
);
const DuskBase: React.FC<{ id: string }> = ({ id }) => (
  <g>
    <defs>
      <linearGradient id={`${id}-b`} x1="0" y1="0" x2="0" y2="1">
        <stop offset="0" stopColor="#5A4E78" />
        <stop offset="1" stopColor="#E9A27F" />
      </linearGradient>
    </defs>
    <rect width={1920} height={1080} fill={`url(#${id}-b)`} />
  </g>
);
export const Ward: React.FC = () => (
  <g>
    <rect width={1920} height={1080} fill="#CFD8D2" />
    <rect y={820} width={1920} height={260} fill="#9AA79F" />
    <rect x={1400} y={160} width={320} height={380} fill="#BFD4E4" stroke={INK} strokeWidth={6} />
    <path d="M 1560 160 V 540 M 1400 350 H 1720" stroke={INK} strokeWidth={5} />
    <rect width={1920} height={1080} fill="#000" opacity={0.12} />
  </g>
);

export const Ship: React.FC<{ x: number; y: number; s?: number; tilt?: number; sink?: number; fire?: boolean; t?: number; color?: string }> = ({ x, y, s = 1, tilt = 0, sink = 0, fire = false, t = 0, color = '#5C6670' }) => (
  <g transform={`translate(${x} ${y + sink}) rotate(${tilt}) scale(${s})`}>
    <path d="M -330 0 L 330 0 L 280 70 L -290 70 Z" fill={color} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <rect x={-170} y={-70} width={260} height={70} fill="#7A838C" stroke={INK} strokeWidth={6} />
    <rect x={-90} y={-130} width={100} height={60} fill="#8A939C" stroke={INK} strokeWidth={6} />
    <rect x={-50} y={-210} width={14} height={80} fill={INK} />
    <rect x={210} y={-34} width={90} height={14} fill={INK} />
    <rect x={-300} y={-34} width={80} height={14} fill={INK} />
    {fire ? [0, 1, 2, 3].map((i) => <circle key={i} cx={-20 + i * 30} cy={-120 - ((t * 3 + i * 40) % 160)} r={34 + i * 6} fill={i % 2 ? '#3A3A3F' : '#E8963A'} opacity={0.75 - ((t * 3 + i * 40) % 160) / 260} />) : null}
  </g>
);
export const Plane: React.FC<{ x: number; y: number; s?: number; rot?: number; smoke?: boolean; t?: number; color?: string }> = ({ x, y, s = 1, rot = 0, smoke = false, t = 0, color = '#C9CED2' }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    {smoke ? [0, 1, 2, 3, 4].map((i) => <circle key={i} cx={-160 - i * 55 - ((t * 2) % 30)} cy={-6 + i * 5} r={20 + i * 8} fill="#3A3A3F" opacity={0.6 - i * 0.1} />) : null}
    <path d="M -140 0 Q -140 -26 -90 -26 L 120 -22 Q 170 -10 170 6 Q 120 26 -90 26 Q -140 24 -140 0 Z" fill={color} stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <path d="M -10 -4 L -60 -110 L -22 -110 L 50 -4 Z" fill="#AEB4B8" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <path d="M -10 4 L -60 110 L -22 110 L 50 4 Z" fill="#AEB4B8" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <path d="M -140 -4 L -176 -56 L -150 -56 L -112 -10 Z" fill="#AEB4B8" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
    <ellipse cx={72} cy={-10} rx={26} ry={13} fill="#C7E3EE" stroke={INK} strokeWidth={4} />
  </g>
);
export const Heli: React.FC<{ x: number; y: number; s?: number; t?: number; rot?: number }> = ({ x, y, s = 1, t = 0, rot = 0 }) => (
  <g transform={`translate(${x} ${y}) rotate(${rot}) scale(${s})`}>
    <path d="M -230 -26 L -90 -10 L -90 18 L -230 -6 Z" fill="#5A6048" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <path d="M -240 -70 L -226 -70 L -214 -10 L -236 -10 Z" fill="#5A6048" stroke={INK} strokeWidth={5} />
    <path d="M -110 0 Q -110 -70 0 -70 Q 120 -70 130 0 Q 120 62 20 62 Q -110 62 -110 0 Z" fill="#6B7348" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <path d="M 20 -56 Q 100 -54 114 -6 L 20 -6 Z" fill="#C7E3EE" stroke={INK} strokeWidth={5} strokeLinejoin="round" />
    <rect x={-8} y={-86} width={16} height={20} fill={INK} />
    <ellipse cx={0} cy={-92} rx={Math.abs(240 * Math.cos(t * 1.3)) + 40} ry={7} fill={INK} opacity={0.75} />
    <path d="M -100 82 H 120 M -60 62 V 82 M 60 62 V 82" stroke={INK} strokeWidth={7} strokeLinecap="round" />
  </g>
);
export const Tank: React.FC<{ x: number; y: number; s?: number; fire?: boolean; t?: number; facing?: number }> = ({ x, y, s = 1, fire = false, t = 0, facing = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s * facing} ${s})`}>
    <rect x={-190} y={-60} width={380} height={60} rx={14} fill="#565D39" stroke={INK} strokeWidth={6} />
    <rect x={-110} y={-130} width={190} height={74} rx={12} fill="#6B7348" stroke={INK} strokeWidth={6} />
    <rect x={70} y={-108} width={190} height={20} fill="#565D39" stroke={INK} strokeWidth={5} />
    <rect x={-210} y={-6} width={420} height={44} rx={22} fill="#2E3026" stroke={INK} strokeWidth={6} />
    {[-150, -75, 0, 75, 150].map((cx) => <circle key={cx} cx={cx} cy={16} r={14} fill="#4A4F35" stroke={INK} strokeWidth={4} />)}
    {fire ? [0, 1, 2].map((i) => <circle key={i} cx={-30 + i * 40} cy={-140 - ((t * 3 + i * 30) % 120)} r={30 + i * 8} fill={i === 1 ? '#3A3A3F' : '#E8963A'} opacity={0.7 - ((t * 3 + i * 30) % 120) / 200} />) : null}
  </g>
);
export const Bed: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-260} y={-110} width={20} height={150} fill="#8D8A7B" stroke={INK} strokeWidth={5} />
    <rect x={240} y={-60} width={20} height={100} fill="#8D8A7B" stroke={INK} strokeWidth={5} />
    <rect x={-250} y={-40} width={510} height={50} rx={8} fill="#E8E4D8" stroke={INK} strokeWidth={6} />
    <rect x={-240} y={-62} width={150} height={32} rx={16} fill="#F4F0E4" stroke={INK} strokeWidth={5} />
    <path d="M -80 -50 H 250 V -4 H -80 Z" fill="#7FA6C8" stroke={INK} strokeWidth={6} />
  </g>
);
export const Book: React.FC<{ x: number; y: number; t: number; d?: number; title: string; s?: number; color?: string }> = ({ x, y, t, d = 0, title, s = 1, color = '#8E2A1E' }) => {
  const k = pop(t, d, 8);
  if (k <= 0) return null;
  return (
    <g transform={`translate(${x} ${y}) rotate(-4) scale(${s * k})`}>
      <rect x={-130} y={-180} width={260} height={360} rx={10} fill={color} stroke={INK} strokeWidth={7} />
      <rect x={-130} y={-180} width={36} height={360} fill="#000" opacity={0.22} />
      <text y={-40} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={title.length > 10 ? 38 : 52} fill="#F1E6CC" letterSpacing={2}>
        {title.split('|').map((ln, i) => <tspan key={i} x={10} dy={i ? 46 : 0}>{ln}</tspan>)}
      </text>
    </g>
  );
};
export const Capitol: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-300} y={-120} width={600} height={120} fill="#E4E0D4" stroke={INK} strokeWidth={6} />
    <path d="M -330 -120 L 0 -190 L 330 -120 Z" fill="#CFCABB" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    {[-240, -160, -80, 0, 80, 160, 240].map((cx) => <rect key={cx} x={cx - 14} y={-112} width={28} height={104} fill="#F4F0E4" stroke={INK} strokeWidth={4} />)}
    <rect x={-90} y={-250} width={180} height={64} fill="#E4E0D4" stroke={INK} strokeWidth={6} />
    <path d="M -80 -250 Q 0 -360 80 -250 Z" fill="#F4F0E4" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <rect x={-4} y={-400} width={8} height={50} fill={INK} />
  </g>
);
export const Bank: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-200} y={-100} width={400} height={100} fill="#D8D2BE" stroke={INK} strokeWidth={6} />
    <path d="M -230 -100 L 0 -170 L 230 -100 Z" fill="#BDB69F" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    {[-150, -75, 0, 75, 150].map((cx) => <rect key={cx} x={cx - 12} y={-92} width={24} height={86} fill="#F1ECDA" stroke={INK} strokeWidth={4} />)}
    <text y={-118} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={38} fill={INK} letterSpacing={6}>BANK</text>
  </g>
);
export const School: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <rect x={-220} y={-170} width={440} height={170} fill="#C8402F" stroke={INK} strokeWidth={6} />
    <path d="M -250 -170 L 0 -270 L 250 -170 Z" fill="#8E2A1E" stroke={INK} strokeWidth={6} strokeLinejoin="round" />
    <rect x={-40} y={-110} width={80} height={110} fill="#F1E6CC" stroke={INK} strokeWidth={5} />
    {[-150, 110].map((wx) => <rect key={wx} x={wx} y={-130} width={60} height={60} fill="#C7E3EE" stroke={INK} strokeWidth={5} />)}
    <rect x={-14} y={-330} width={28} height={70} fill="#F1E6CC" stroke={INK} strokeWidth={5} />
  </g>
);
export const Coin: React.FC<{ x: number; y: number; t: number; d?: number; s?: number }> = ({ x, y, t, d = 0, s = 1 }) => {
  const k = pop(t, d, 6);
  if (k <= 0) return null;
  return (
    <g transform={`translate(${x} ${y}) scale(${s * k})`}>
      <circle r={44} fill="#E7C766" stroke={INK} strokeWidth={6} />
      <circle r={32} fill="none" stroke="#B8962E" strokeWidth={4} />
      <text y={16} textAnchor="middle" fontFamily={FONT.title} fontWeight={800} fontSize={48} fill="#8A6A1E">$</text>
    </g>
  );
};
export const Wreath: React.FC<{ x: number; y: number; s?: number }> = ({ x, y, s = 1 }) => (
  <g transform={`translate(${x} ${y}) scale(${s})`}>
    <circle r={52} fill="none" stroke="#3E6E3A" strokeWidth={22} />
    <circle r={52} fill="none" stroke="#5A8E4F" strokeWidth={8} strokeDasharray="10 12" />
    <path d="M -14 50 L 0 74 L 14 50 Z" fill="#C8402F" stroke={INK} strokeWidth={4} />
    {[0, 1, 2, 3].map((i) => <circle key={i} cx={Math.cos(i * 1.6) * 52} cy={Math.sin(i * 1.6) * 52} r={7} fill="#C8402F" />)}
  </g>
);
export const Wound: React.FC<{ x: number; y: number; t: number; d?: number }> = ({ x, y, t, d = 0 }) => {
  const k = pop(t, d, 4);
  if (k <= 0) return null;
  return <g transform={`translate(${x} ${y}) scale(${k})`}><circle r={7} fill={DOS.red} stroke={INK} strokeWidth={3} /></g>;
};
