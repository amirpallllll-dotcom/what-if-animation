import React from 'react';
import { clamp, easeOut, kf, rnd, settle } from './anim';
import { Hero, Pose, Look, Expr, basePose, joints, toWorld, LEG_LEN, LOOKS } from './rig';

// The CAST kit (shared core, no niche in it): more people, a library of actions, head gear and a crowd that flips mood.
// Everything is a pure function of the shot clock t (frames).
//
//   <Person pose={actionPose('walk', t, { x: 300, ground: 830, speed: 8 })} look={CAST.soldier} gear="cap" />
//   <Crowd t={t} x={960} ground={860} count={12} moods={[{ f: 0, action: 'cheer' }, { f: 40, action: 'shock' }]} />
//
// Actions: idle walk run point salute bow shrug wave cheer shock sad think nod.
// Walk, run, point-sideways and bow turn the body to profile (facing 1 = right, -1 = left); the rest face the camera.

const SK = '#F6EFE3';
const SKS = '#E2D3BE';
const mk = (jacket: string, jacketShade: string, limb: string, shoe: string, hair: string, accent: string, skin = SK, skinShade = SKS, line = '#14121C'): Look => ({
  skin, skinShade, hand: skin, jacket, jacketShade, accent, limb, line, shoe, face: '#1D2033', hair,
});

/** Extra people, all plain shapes in the same flat look (colours only; add gear for hats). */
export const CAST: Record<'soldier' | 'officer' | 'pilot' | 'elder' | 'kid' | 'aunt' | 'worker', Look> = {
  soldier: mk('#6B7348', '#565D39', '#4A4F35', '#3B2F25', '#2A1C18', '#C9B26A'),
  officer: mk('#2F3E5C', '#25314A', '#232C40', '#14151A', '#17141A', '#D9B84A'),
  pilot: mk('#7A5230', '#62411F', '#4A3A2C', '#2B2018', '#2A1C18', '#C9B26A'),
  elder: mk('#7C6A52', '#645541', '#4A4034', '#3B2F25', '#D8D4CC', '#B9A57A', '#E3CDB4', '#CDB69A'),
  kid: mk('#D9743F', '#B95E30', '#3A3446', '#4E8F4A', '#2A1C18', '#F2C14E'),
  aunt: mk('#8A4F6E', '#704058', '#3A3446', '#5A4A6A', '#3A2620', '#E9C46A', '#DDBB9B', '#C7A584'),
  worker: mk('#3E6E8A', '#305870', '#2F3A4A', '#3B2F25', '#2A1C18', '#F2C14E', '#C98E68', '#B07A58'),
};

export type GearKind = 'cap' | 'pilot' | 'beanie' | 'scarf' | 'none';

/** Head gear drawn on top of the head (front view). Colour is optional. */
export const Gear: React.FC<{ pose: Pose; kind: GearKind; color?: string }> = ({ pose, kind, color }) => {
  if (kind === 'none') return null;
  const hd = toWorld(pose, joints(pose).head);
  const ink = '#14121C';
  return (
    <g transform={`translate(${hd.x} ${hd.y}) rotate(${pose.tilt + pose.headTilt + pose.spin}) scale(${pose.scale})`}>
      {kind === 'cap' ? (
        <g>
          <path d="M -61 -40 Q -64 -86 0 -88 Q 64 -86 61 -40 Z" fill={color ?? '#6B7348'} stroke={ink} strokeWidth={5} strokeLinejoin="round" />
          <rect x={-62} y={-52} width={124} height={14} fill={color ? ink : '#565D39'} opacity={0.5} />
          <circle cx={0} cy={-62} r={8} fill="#C9B26A" stroke={ink} strokeWidth={3} />
          <path d="M -46 -40 Q 0 -26 46 -40 L 42 -33 Q 0 -19 -42 -33 Z" fill={ink} />
        </g>
      ) : null}
      {kind === 'pilot' ? (
        <g>
          <path d="M -68 14 Q -76 -96 0 -96 Q 76 -96 68 14 L 54 14 Q 52 -32 0 -44 Q -52 -32 -54 14 Z" fill={color ?? '#7A5230'} stroke={ink} strokeWidth={5} strokeLinejoin="round" />
          <path d="M -64 -50 Q 0 -62 64 -50" stroke={ink} strokeWidth={7} fill="none" />
          <circle cx={-24} cy={-54} r={19} fill="#C7E3EE" stroke={ink} strokeWidth={5} opacity={0.95} />
          <circle cx={24} cy={-54} r={19} fill="#C7E3EE" stroke={ink} strokeWidth={5} opacity={0.95} />
          <path d="M -5 -54 L 5 -54" stroke={ink} strokeWidth={6} />
        </g>
      ) : null}
      {kind === 'beanie' ? (
        <g>
          <path d="M -60 -34 Q -62 -88 0 -90 Q 62 -88 60 -34 Z" fill={color ?? '#C8402F'} stroke={ink} strokeWidth={5} strokeLinejoin="round" />
          <rect x={-62} y={-48} width={124} height={16} rx={6} fill={color ? ink : '#8E2A1E'} opacity={0.55} />
          <circle cx={0} cy={-94} r={10} fill={color ?? '#C8402F'} stroke={ink} strokeWidth={4} />
        </g>
      ) : null}
      {kind === 'scarf' ? (
        <path
          d="M -74 4 A 74 84 0 0 1 74 4 L 74 46 Q 62 90 0 94 Q -62 90 -74 46 Z M -50 6 A 50 58 0 0 1 50 6 L 50 34 Q 42 62 0 64 Q -42 62 -50 34 Z"
          fillRule="evenodd"
          fill={color ?? '#4E6E8A'}
          stroke={ink}
          strokeWidth={5}
          strokeLinejoin="round"
        />
      ) : null}
    </g>
  );
};

/** A person: the Hero rig plus optional head gear. */
export const Person: React.FC<{ pose: Pose; look?: Look; gear?: GearKind; gearColor?: string; shadow?: number }> = ({ pose, look = LOOKS.pipHood, gear = 'none', gearColor, shadow = 0.6 }) => (
  <g>
    <Hero look={look} pose={pose} shadow={shadow} />
    <Gear pose={pose} kind={gear} color={gearColor} />
  </g>
);

export type ActionName = 'idle' | 'walk' | 'run' | 'point' | 'salute' | 'bow' | 'shrug' | 'wave' | 'cheer' | 'shock' | 'sad' | 'think' | 'nod' | 'aim' | 'fire' | 'carry' | 'stir';
export type ActOpts = {
  x: number; // where the body is at t = 0
  ground: number; // y of the ground under the feet
  scale?: number;
  facing?: 1 | -1;
  speed?: number; // walk/run: pixels per frame in the facing direction
  side?: 'left' | 'right' | 'up'; // point: where
  hold?: number; // bow: frames held down
  expr?: Expr;
};

const sin = Math.sin;

/** The pose of an action at clock t (loops for walk/run/wave/cheer/idle/nod, plays once and holds for the rest). */
export const actionPose = (name: ActionName, t: number, o: ActOpts): Pose => {
  const scale = o.scale ?? 1;
  const facing = o.facing ?? 1;
  const base: Pose = { ...basePose, x: o.x, y: o.ground - LEG_LEN * scale, scale, facing, yaw: 0, expr: o.expr ?? 'neutral' };
  const tt = Math.max(0, t);
  switch (name) {
    case 'walk':
    case 'run': {
      const run = name === 'run';
      const ph = tt * (run ? 0.72 : 0.46);
      const A = run ? 46 : 24;
      const K = run ? 70 : 34;
      const leg = (p: number) => ({ a: A * sin(p), b: -(8 + K * Math.max(0, Math.cos(p))) });
      const sw = (run ? 55 : 26) * sin(ph);
      const bend = (run ? 62 : 12) * facing;
      return {
        ...base,
        x: o.x + facing * (o.speed ?? 0) * tt,
        y: base.y - (run ? 10 : 5) * (1 - Math.abs(sin(ph))),
        yaw: facing,
        tilt: (run ? 10 : 2) * facing,
        legL: leg(ph),
        legR: leg(ph + Math.PI),
        armR: { a: facing * sw, b: bend },
        armL: { a: -facing * sw, b: -bend },
        expr: o.expr ?? (run ? 'worried' : 'neutral'),
        sway: sin(ph) * 6,
      };
    }
    case 'point': {
      const k = easeOut(clamp(tt / 8));
      const side = o.side ?? (facing === 1 ? 'right' : 'left');
      const arm = { a: side === 'up' ? 165 * k : 88 * k + 6 * (1 - k), b: 0 };
      return {
        ...base,
        armR: side === 'left' ? { a: 8, b: -6 } : arm,
        armL: side === 'left' ? arm : { a: 8, b: -6 },
        handR: side !== 'left' ? 'point' : 'open',
        handL: side === 'left' ? 'point' : 'open',
        headTilt: side === 'left' ? -4 : 4,
        expr: o.expr ?? 'smug',
        look: side === 'left' ? -1 : 1,
      };
    }
    case 'salute': {
      const k = easeOut(clamp(tt / 6));
      return { ...base, armR: { a: 8 + 90 * k, b: -6 + 118 * k }, armL: { a: 6, b: -4 }, headTilt: -2 * k, expr: o.expr ?? 'neutral' };
    }
    case 'bow': {
      const h = o.hold ?? 24;
      const c = kf(tt, [[0, 0], [10, 1], [10 + h, 1], [20 + h, 0]]);
      return { ...base, yaw: facing * 0.55, tilt: facing * 34 * c, headTilt: facing * 6 * c, armR: { a: 10 + 8 * c, b: -8 }, armL: { a: 10 + 8 * c, b: -8 }, expr: o.expr ?? 'neutral' };
    }
    case 'shrug': {
      const k = easeOut(clamp(tt / 8));
      const w = tt > 8 ? sin((tt - 8) * 0.35) * 5 : 0;
      return { ...base, armR: { a: 8 + 32 * k, b: -8 + 100 * k + w }, armL: { a: 8 + 32 * k, b: -8 + 100 * k - w }, headTilt: 8 * k, expr: o.expr ?? 'worried', look: sin(tt * 0.12) * 0.5 };
    }
    case 'wave': {
      return { ...base, armR: { a: 150, b: 28 * sin(tt * 0.55) }, armL: { a: 8, b: -6 }, headTilt: 4, expr: o.expr ?? 'happy' };
    }
    case 'cheer': {
      const hop = Math.abs(sin(tt * 0.34));
      return { ...base, y: base.y - 42 * hop, squash: -0.06 * hop, armR: { a: 160, b: 8 }, armL: { a: 160, b: 8 }, legL: { a: 6 * hop, b: -10 * hop }, legR: { a: -6 * hop, b: -10 * hop }, expr: o.expr ?? 'happy' };
    }
    case 'shock': {
      const k = easeOut(clamp(tt / 5));
      return {
        ...base,
        x: o.x - facing * 16 * k + settle(tt, 4, 2.2, 5),
        tilt: -facing * 9 * k,
        squash: -0.05 * k + settle(tt, 0.05, 1.8, 6),
        armR: { a: 8 + 34 * k, b: -6 + 72 * k },
        armL: { a: 8 + 34 * k, b: -6 + 72 * k },
        expr: o.expr ?? 'shock',
      };
    }
    case 'sad': {
      const k = easeOut(clamp(tt / 14));
      return { ...base, tilt: 5 * k * facing, headTilt: 12 * k * facing, armR: { a: 6, b: -4 }, armL: { a: 6, b: -4 }, y: base.y + 4 * k + sin(tt * 0.1) * 1.5, expr: o.expr ?? 'tired', look: -0.4 };
    }
    case 'think': {
      const k = easeOut(clamp(tt / 8));
      return { ...base, armR: { a: 8 + 42 * k, b: -6 + 146 * k }, armL: { a: 8, b: -6 }, headTilt: 7 * k, expr: o.expr ?? 'neutral', look: 0.8 * k };
    }
    case 'nod': {
      return { ...base, headTilt: 9 * sin(tt * 0.4), expr: o.expr ?? 'happy' };
    }
    case 'aim':
    case 'fire': {
      // rifle/gun stance: body in profile, both arms reaching toward facing; fire adds recoil kick every 5 frames
      const k = easeOut(clamp(tt / 6));
      const fire = name === 'fire';
      const kick = fire ? Math.max(0, 1 - (tt % 5) / 3) : 0;
      const front = { a: 84 * k + 4 * (1 - k) - 2 * kick, b: -2 };
      const back = { a: -(46 * k) + 8 * (1 - k), b: -(66 * k) };
      return {
        ...base,
        x: o.x - facing * 7 * kick,
        yaw: facing * 0.78,
        tilt: facing * (4 * k + 2 * kick),
        armR: facing === 1 ? front : back,
        armL: facing === 1 ? back : front,
        legL: { a: 14 * k, b: -4 },
        legR: { a: -16 * k, b: -4 },
        headTilt: facing * -3 * k,
        expr: o.expr ?? 'cool',
        look: facing * 0.9,
        sway: fire ? sin(tt * 1.3) * 4 : 0,
      };
    }
    case 'carry': {
      // bending forward under a load: walks slowly, both arms low and forward
      const ph = tt * 0.3;
      const k = easeOut(clamp(tt / 10));
      return {
        ...base,
        x: o.x + facing * (o.speed ?? 0) * tt,
        y: base.y - 3 * (1 - Math.abs(sin(ph))) + 6 * k,
        yaw: facing * 0.6,
        tilt: facing * 20 * k,
        headTilt: facing * -6 * k,
        legL: { a: 16 * sin(ph), b: -(6 + 22 * Math.max(0, Math.cos(ph))) },
        legR: { a: -16 * sin(ph), b: -(6 + 22 * Math.max(0, -Math.cos(ph))) },
        armR: facing === 1 ? { a: 62 * k, b: 30 * k } : { a: -50 * k, b: -50 * k },
        armL: facing === 1 ? { a: -50 * k, b: -50 * k } : { a: 62 * k, b: 30 * k },
        expr: o.expr ?? 'worried',
        sway: sin(ph) * 3,
      };
    }
    case 'stir': {
      // stirring a pot: one arm forward-down making small circles, other on hip
      const k = easeOut(clamp(tt / 8));
      const ph = tt * 0.42;
      const stirArm = { a: 52 * k + 7 * sin(ph), b: 38 * k + 10 * Math.cos(ph) };
      return {
        ...base,
        yaw: facing * 0.45,
        tilt: facing * 4 * k,
        armR: facing === 1 ? stirArm : { a: 6, b: 4 },
        armL: facing === 1 ? { a: 6, b: 4 } : stirArm,
        headTilt: facing * 4 * k,
        expr: o.expr ?? 'neutral',
        look: facing * 0.5,
        sway: sin(ph) * 2,
      };
    }
    default: {
      return { ...base, squash: 0.012 * sin(tt * 0.15), headTilt: 1.5 * sin(tt * 0.07), sway: 3 * sin(tt * 0.1) };
    }
  }
};

export type Mood = { f: number; action: ActionName; expr?: Expr };

/** A crowd of people who change mood together (each reacts a few frames apart). Rows stack back to front. */
export const Crowd: React.FC<{
  t: number;
  x?: number;
  ground?: number;
  count?: number;
  gap?: number;
  scale?: number;
  rows?: number;
  seed?: number;
  looks?: Look[];
  gears?: GearKind[];
  moods: Mood[];
}> = ({ t, x = 960, ground = 880, count = 6, gap = 300, scale = 0.95, rows = 2, seed = 3, looks, gears, moods }) => {
  const L = looks ?? [CAST.soldier, CAST.worker, CAST.aunt, CAST.elder, CAST.kid, CAST.officer];
  const people: React.ReactNode[] = [];
  for (let r = 0; r < rows; r++) {
    const rs = rows > 1 ? 0.86 + 0.14 * (r / (rows - 1)) : 1;
    const gy = ground - (rows - 1 - r) * 46;
    for (let i = 0; i < count; i++) {
      const idx = r * count + i;
      const delay = Math.floor(rnd(seed, idx) * 7);
      let cur = moods[0];
      for (const m of moods) if (t - delay >= m.f) cur = m;
      const px = x + (i - (count - 1) / 2) * gap + (r % 2 ? gap / 2 : 0) + (rnd(seed + 1, idx) - 0.5) * 40;
      const sc = scale * rs * (0.94 + rnd(seed + 2, idx) * 0.12);
      const pose = actionPose(cur.action, t - delay - cur.f + Math.floor(rnd(seed + 3, idx) * 10), { x: px, ground: gy, scale: sc, expr: cur.expr });
      const g = gears ? gears[idx % gears.length] : 'none';
      people.push(<Person key={idx} pose={pose} look={L[idx % L.length]} gear={g} shadow={0.3} />);
    }
  }
  return <g>{people}</g>;
};
