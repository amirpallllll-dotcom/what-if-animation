import { defineEpisode, Timeline } from '../../engine';
import { mk, Spec } from './scene';
import specs from './specs.json';
import tls from './timelines.json';
import mspecs from './specs_miller.json';
import mtls from './timelines_miller.json';

// "7 legendary veterans" (Vet00 ... Vet99) plus the Miller test (Miller). Military pack only.
const all = { ...(specs as unknown as Record<string, Spec>), ...(mspecs as unknown as Record<string, Spec>) };
const SHOTS = Object.fromEntries(Object.entries(all).map(([id, sp]) => [id, mk(id, sp)]));
export const vetEpisodes = Object.entries({ ...tls, ...mtls }).map(([id, tl]) => defineEpisode(id, { timeline: tl as unknown as Timeline, shots: SHOTS }));
