import React from 'react';
import {
  ShotProps, camT, kf, clamp, easeOut, actionPose, ActionName, Expr, DOS, FONT,
  Chip, CounterChip, Stamp, PunchWord, MarkPop, StatusCard, Card, Checklist, DuskHills, ChalkBoard,
  VLOOKS, Vet, HelmKind, CaseFile, Medal, Headstone, Flag, NightForest, Banner, Folder, WarRoom,
  SeaBG, SkyBG, Ridge, Ward, Ship, Plane, Heli, Tank, Bed, Book, Capitol, Bank, School, Coin, Wreath, Wound,
  Gun, MuzzleFlash, Smoke, Blast, Torpedo, Submarine, Podium, StockPot, ShipDeck, Galley,
} from '../../engine';

// A tiny scene language: a shot = background + people + things. Every shot function is still a pure function of t.
export type PSpec = {
  look?: keyof typeof VLOOKS; helm?: HelmKind; hc?: string; act?: ActionName; x: number; gd?: number; sc?: number; face?: 1 | -1;
  expr?: Expr | 'determined'; gun?: 'rifle' | 'mg'; spin?: number; dx?: number; dy?: number; speed?: number; side?: 'left' | 'right' | 'up'; lag?: number; hold?: number; from?: number; swing?: boolean;
};
export type Thing = { k: string; [key: string]: any };
export type Spec = {
  bg?: 'dusk' | 'night' | 'room' | 'sea' | 'sky' | 'ridge' | 'ward' | 'dark' | 'day' | 'chalk' | 'deck' | 'galley';
  tint?: { c: string; o: [number, number] };
  sun?: number; sunY?: number; dim?: number; cam?: { z?: [number, number]; cx?: [number, number]; cy?: [number, number] };
  people?: PSpec[]; back?: Thing[]; things?: Thing[]; fade?: boolean; seaDusk?: boolean;
};

const renderThing = (th0: Thing, t: number, len: number, i: number): React.ReactNode => {
  const v = (a: any) => (Array.isArray(a) ? a[0] + (a[1] - a[0]) * clamp(t / len) : a);
  const th: Thing = { ...th0, x: v(th0.x), y: v(th0.y), tilt: v(th0.tilt), sink: v(th0.sink), rot: v(th0.rot) };
  const d = th.d ?? 0;
  switch (th.k) {
    case 'chip': return <Chip key={i} x={th.x} y={th.y} t={t} d={d} text={th.text} color={th.color} zoom={th.zoom} />;
    case 'counter': return <CounterChip key={i} x={th.x} y={th.y} t={t} d={d} label={th.label} from={th.from} to={th.to} at={th.at} dur={th.dur} prefix={th.prefix} suffix={th.suffix} zoom={th.zoom} />;
    case 'stamp': return <Stamp key={i} x={th.x} y={th.y} t={t} d={d} text={th.text} color={th.color} rot={th.rot} size={th.size} />;
    case 'punch': return <PunchWord key={i} x={th.x} y={th.y} t={t} d={d} text={th.text} color={th.color} size={th.size} rot={th.rot} />;
    case 'mark': return <MarkPop key={i} x={th.x} y={th.y} t={t} d={d} mark={th.mark} hold={th.hold} />;
    case 'medal': return <Medal key={i} x={th.x} y={th.y} t={t} d={d} kind={th.kind} scale={th.s} />;
    case 'stone': return <Headstone key={i} x={th.x} y={th.y} t={t} d={d} name={th.name} dates={th.dates} scale={th.s} rise={th.rise} />;
    case 'flag': return <Flag key={i} x={th.x} y={th.y} t={t} d={d} w={th.w} h={th.h} pole={typeof th.pole === 'number' ? th.pole : undefined} />;
    case 'status': return <StatusCard key={i} x={th.x} y={th.y} t={t} d={d} title={th.title} rows={th.rows} at={th.at} dur={th.dur} zoom={th.zoom ?? 1.2} />;
    case 'case': return <CaseFile key={i} x={th.x ?? 960} y={th.y ?? 520} t={t} d={d} name={th.name} lines={th.lines} stamp={th.stamp} stampAt={th.stampAt} zoom={th.zoom} />;
    case 'card':
      return (
        <g key={i}>
          <Card x={th.x} y={th.y} w={th.w ?? 620} h={th.h ?? 100 + 64 * th.lines.length} t={t} d={d} title={th.title} zoom={th.zoom ?? 1.35} rot={th.rot ?? 0}>
            {th.lines.map((ln: string, j: number) => (
              <text key={j} x={36} y={110 + j * 62} fontFamily={FONT.ui} fontSize={30} letterSpacing={2} fill={DOS.ink} opacity={clamp((t - d - 6 - j * 5) / 4)}>{ln}</text>
            ))}
          </Card>
        </g>
      );
    case 'check': return <Checklist key={i} x={th.x} y={th.y} t={t} d={d} title={th.title} items={th.items} zoom={th.zoom ?? 1.5} />;
    case 'ship': return <Ship key={i} x={th.x} y={th.y} s={th.s} tilt={th.tilt} sink={th.sink} fire={th.fire} t={t} color={th.color} />;
    case 'plane': return <Plane key={i} x={th.x} y={th.y} s={th.s} rot={th.rot} smoke={th.smoke} t={t} />;
    case 'heli': return <Heli key={i} x={th.x} y={th.y} s={th.s} t={t} rot={th.rot} />;
    case 'tank': return <Tank key={i} x={th.x} y={th.y} s={th.s} fire={th.fire} t={t} facing={th.facing} />;
    case 'bed': return <Bed key={i} x={th.x} y={th.y} s={th.s} />;
    case 'book': return <Book key={i} x={th.x} y={th.y} t={t} d={d} title={th.title} s={th.s} color={th.color} />;
    case 'capitol': return <Capitol key={i} x={th.x} y={th.y} s={th.s} />;
    case 'bank': return <Bank key={i} x={th.x} y={th.y} s={th.s} />;
    case 'school': return <School key={i} x={th.x} y={th.y} s={th.s} />;
    case 'coin': return <Coin key={i} x={th.x} y={th.y} t={t} d={d} s={th.s} />;
    case 'wreath': return <Wreath key={i} x={th.x} y={th.y} s={th.s} />;
    case 'wound': return <Wound key={i} x={th.x} y={th.y} t={t} d={d} />;
    case 'banner': return <Banner key={i} x={th.x} y={th.y} t={t} d={d} text={th.text} />;
    case 'folder': return <Folder key={i} x={th.x} y={th.y} t={t} d={d} n={th.n} rot={th.rot} scale={th.s} />;
    case 'line': return <line key={i} x1={th.x1} y1={th.y1} x2={th.x1 + (th.x2 - th.x1) * easeOut(clamp((t - d) / (th.dur ?? 30)))} y2={th.y1 + (th.y2 - th.y1) * easeOut(clamp((t - d) / (th.dur ?? 30)))} stroke={th.color ?? DOS.paper} strokeWidth={th.w ?? 8} strokeDasharray={typeof th.dash === 'string' ? th.dash : th.dash ? '22 14' : undefined} />;
    case 'text': return t < d ? null : <text key={i} x={th.x} y={th.y} textAnchor={th.anchor ?? 'middle'} fontFamily={th.hand ? FONT.hand : FONT.title} fontWeight={800} fontSize={th.size ?? 80} fill={th.color ?? '#F4F0E4'} opacity={clamp((t - d) / 6)}>{th.text}</text>;
    case 'smoke': return <Smoke key={i} x={th.x} y={th.y} t={t} d={d} s={th.s} n={th.n} color={th.color} />;
    case 'blast': return <Blast key={i} x={th.x} y={th.y} t={t} d={d} s={th.s} />;
    case 'torpedo': return <Torpedo key={i} x1={th.x1} x2={th.x2} y={th.y} t={t} d={d} dur={th.dur} s={th.s} />;
    case 'submarine': return <Submarine key={i} x={th.x} y={th.y} s={th.s} t={t} facing={th.facing} />;
    case 'podium': return <Podium key={i} x={th.x} y={th.y} s={th.s} />;
    case 'stock_pot': return <StockPot key={i} x={th.x} y={th.y} t={t} s={th.s} />;
    case 'muzzle_flash': return <MuzzleFlash key={i} x={th.x} y={th.y} t={t} d={d} s={th.s} />;
    case 'machine_gun': case 'rifle': return <g key={i} transform={`translate(${th.x} ${th.y}) scale(${(th.facing ?? 1) * (th.s ?? 1)} ${th.s ?? 1})`}><Gun kind={th.k === 'rifle' ? 'rifle' : 'mg'} /></g>;
    case 'rect': return <rect key={i} x={th.x} y={th.y} width={th.w} height={th.h} fill={th.fill} opacity={th.o ?? 1} rx={th.rx ?? 0} stroke={th.stroke} strokeWidth={th.sw} />;
    default: return null;
  }
};

// On-screen labels stay put on screen while the camera moves (they are drawn outside the camera group).
const HUD = new Set(['chip', 'counter']);

export const mk = (id: string, sp: Spec): React.FC<ShotProps> => {
  const Shot: React.FC<ShotProps> = ({ t, len }) => {
    const c = sp.cam ?? {};
    const z = c.z ?? [1.0, 1.06];
    const cx = c.cx ?? [960, 960];
    const cy = c.cy ?? [540, 540];
    return (
      <g>
        <g transform={camT(kf(t, [[0, cx[0]], [len, cx[1]]]), kf(t, [[0, cy[0]], [len, cy[1]]]), kf(t, [[0, z[0]], [len, z[1]]]))}>
          <rect id="basefill" x={-1500} y={-900} width={4920} height={2880} fill="#14161E" />
          {sp.bg === 'night' ? <NightForest t={t} id={id} /> : null}
          {sp.bg === 'room' ? <WarRoom /> : null}
          {sp.bg === 'dusk' || sp.bg === undefined ? <DuskHills t={t} id={id} sunX={sp.sun} sunY={sp.sunY} /> : null}
          {sp.bg === 'sea' ? <SeaBG t={t} id={id} dusk={sp.seaDusk} /> : null}
          {sp.bg === 'sky' ? <SkyBG t={t} id={id} /> : null}
          {sp.bg === 'ridge' ? <Ridge t={t} id={id} /> : null}
          {sp.bg === 'ward' ? <Ward /> : null}
          {sp.bg === 'deck' ? <ShipDeck t={t} id={id} /> : null}
          {sp.bg === 'galley' ? <Galley /> : null}
          {sp.bg === 'chalk' ? <ChalkBoard /> : null}
          {sp.bg === 'dark' ? <rect width={1920} height={1080} fill="#14161E" /> : null}
          {sp.dim ? <rect width={1920} height={1080} fill="#000" opacity={sp.dim} /> : null}
          {(sp.back ?? []).map((th, i) => renderThing(th, t, len, i))}
          {(sp.people ?? []).map((p, i) => {
            const k = p.from !== undefined ? clamp((t - p.from) / 5) : 1;
            if (k <= 0) return null;
            const det = p.expr === 'determined';
            let pose = actionPose(p.act ?? 'idle', t - (p.lag ?? 0), { x: p.x, ground: p.gd ?? 900, scale: (p.sc ?? 1.35) * (p.from !== undefined ? easeOut(k) : 1), facing: p.face ?? 1, speed: p.speed, side: p.side, hold: p.hold, expr: det ? 'cool' : (p.expr as Expr | undefined) });
            if (p.spin !== undefined || p.dx || p.dy) pose = { ...pose, spin: p.spin ?? 0, x: pose.x + (p.dx ?? 0), y: pose.y + (p.dy ?? 0) };
            if (p.swing) {
              const sw = Math.sin(t * 0.7);
              pose = { ...pose, armR: { a: 100 + 70 * sw, b: 20 * sw }, armL: { a: 100 - 70 * sw, b: -20 * sw }, tilt: 6 * sw };
            }
            return <Vet key={i} pose={pose} look={VLOOKS[p.look ?? 'soldier']} helm={p.helm ?? 'none'} helmColor={p.hc} gun={p.gun} fireT={p.act === 'fire' ? t : undefined} brows={det} />;
          })}
          {sp.tint ? <rect width={1920} height={1080} fill={sp.tint.c} opacity={sp.tint.o[0] + (sp.tint.o[1] - sp.tint.o[0]) * clamp(t / len)} /> : null}
          {(sp.things ?? []).map((th, i) => (HUD.has(th.k) ? null : renderThing(th, t, len, 100 + i)))}
        </g>
        {(sp.things ?? []).map((th, i) => (HUD.has(th.k) ? renderThing(th, t, len, 200 + i) : null))}
        {sp.fade ? <rect width={1920} height={1080} fill="#000" opacity={clamp((t - (len - 36)) / 30)} /> : null}
      </g>
    );
  };
  return Shot;
};
