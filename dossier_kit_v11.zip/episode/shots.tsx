import React from 'react';
import {
  Hero, poseAt, faceAt, LOOKS, LEG_LEN, easeOut, kf, camT, ShotProps,
  DOS, Card, Stamp, Checklist, Chip, CardRow, Flowchart, RouteMap, AnalogGauge, CounterChip, StatusCard, Ribbon, PunchWord, MarkPop, Scroll,
  DuskHills, DeskTop, ChalkBoard, FONT,
} from '../../engine';

// "DossierDemo": a 17 second test of the Dossier kit on a neutral story (a student whose morning alarm keeps failing).
// Every shot is about 2 seconds, hard cuts, one idea each. The words are placeholders; the kit is the point.
const PIP = LOOKS.pipHood;

const stand = (x: number, scale: number, t: number) =>
  poseAt(t, [{ f: 0, p: { x, y: 820 - LEG_LEN * scale, scale, yaw: 0, armL: { a: 14, b: 6 }, armR: { a: 14, b: 6 } } }]);

// S1: the mission card ticks while Pip stands on the hill
export const S1: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.06]]))}>
    <DuskHills t={t} id="d1" />
    <Hero look={PIP} pose={{ ...stand(560, 0.8, t), ...faceAt(t, [[0, 'happy']]) }} shadow={0.6} />
    <Checklist
      x={1370}
      y={470}
      t={t}
      d={2}
      title="MISSION"
      items={[
        { text: 'WAKE UP', at: 8, mark: 'tick', markAt: 22 },
        { text: 'EAT BREAKFAST', at: 14, mark: 'tick', markAt: 34 },
        { text: 'BE ON TIME', at: 20, mark: 'open' },
      ]}
    />
    <Chip x={90} y={100} t={t} d={4} text="DAY 1" />
  </g>
);

// S2: three log cards on the desk, stamped one after another
export const S2: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.08]]))}>
    <DeskTop />
    <CardRow
      x={960}
      y={540}
      t={t}
      d={0}
      title="MORNING LOG"
      cards={[
        { n: '1', stamp: 'LATE', stampAt: 10, activeAt: 6 },
        { n: '2', stamp: 'LATE', stampAt: 26, activeAt: 22 },
        { n: '3', blank: true, activeAt: 38 },
      ]}
    />
  </g>
);

// S3: a decision chart builds
export const S3: React.FC<ShotProps> = ({ t }) => (
  <g>
    <DeskTop />
    <Flowchart
      t={t}
      d={0}
      nodes={[
        { id: 'a', text: 'ALARM RINGS', x: 430, y: 520, at: 4, w: 340 },
        { id: 'b', text: 'SNOOZE', x: 960, y: 520, at: 16, w: 300, style: 'dashed' },
        { id: 'c', text: 'LATE', x: 1430, y: 520, at: 30, w: 260, style: 'hot' },
      ]}
      arrows={[
        { from: 'a', to: 'b', at: 12 },
        { from: 'b', to: 'c', at: 26, color: DOS.red, dashed: true },
      ]}
    />
  </g>
);

// S4: a route draws across a map and ends in a red X
export const S4: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(kf(t, [[0, 760], [len, 1000]]), kf(t, [[0, 520], [len, 520]]), kf(t, [[0, 1.3], [len, 1.0]]))}>
    <RouteMap
      t={t}
      pins={[
        { x: 330, y: 560, at: 4, label: 'HOME', kind: 'base' },
        { x: 1560, y: 720, at: 8, label: 'SCHOOL', kind: 'target' },
      ]}
      routes={[{ pts: [[330, 520], [640, 380], [960, 450], [1250, 640], [1560, 720]], at: 14, dur: 30, endX: true }]}
    />
  </g>
);

// S5: the fuel gauge drains
export const S5: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.1]]))}>
    <rect width={1920} height={1080} fill="#3A3F44" />
    <AnalogGauge x={960} y={540} t={t} d={0} from={0.8} to={0.1} at={8} dur={26} label="ENERGY" />
  </g>
);

// S6: bars drain and a counter climbs
export const S6: React.FC<ShotProps> = ({ t }) => (
  <g>
    <DeskTop />
    <StatusCard x={800} y={540} t={t} d={0} title="MORNING STATUS" rows={[{ label: 'SLEEP', from: 0.85, to: 0.2 }, { label: 'ENERGY', from: 0.7, to: 0.15 }]} />
    <CounterChip x={1200} y={880} t={t} d={6} label="SNOOZES" from={0} to={3} at={14} dur={24} prefix="x" />
  </g>
);

// S7: chalkboard, a banner drops, one punch word
export const S7: React.FC<ShotProps> = ({ t }) => (
  <g>
    <ChalkBoard />
    <text x={960} y={420} textAnchor="middle" fontFamily={FONT.hand} fontWeight={700} fontSize={100} fill="#F4F0E4" opacity={0.9}>
      Tomorrow is a new day
    </text>
    <Ribbon x={960} y={640} t={t} d={4} text="ALARM FAILED" />
    <PunchWord x={960} y={310} t={t} d={20} text="AGAIN?" color="#FFD54A" size={170} />
  </g>
);

// S8: the rules scroll unrolls; Pip is shocked
export const S8: React.FC<ShotProps> = ({ t, len }) => (
  <g transform={camT(960, 540, kf(t, [[0, 1.0], [len, 1.05]]))}>
    <DuskHills t={t} id="d8" sunX={600} />
    <Hero look={PIP} pose={{ ...stand(450, 0.85, t), ...faceAt(t, [[0, 'shock'], [24, 'worried']]) }} shadow={0.6} />
    <MarkPop x={470} y={300} t={t} d={4} mark="!" />
    <Scroll x={1280} y={470} t={t} d={6} w={760} h={420} id="s8" lines={['THE RULES', 'NO SNOOZE', 'UP IN FIVE', 'BREAKFAST AFTER']} />
  </g>
);
