import { defineEpisode, Timeline } from '../../engine';
import timeline from './timeline.json';
import { S1, S2, S3, S4, S5, S6, S7, S8 } from './shots';

// "DossierDemo": 8 shots, about 17 s, no voice. A test of the Dossier kit.
export const dossierDemo = defineEpisode('DossierDemo', {
  timeline: timeline as Timeline,
  shots: { S1, S2, S3, S4, S5, S6, S7, S8 },
});
