#!/bin/sh
# Installs the Dossier kit and the DossierDemo episode into /workspace/studio. Safe to run twice.
set -e
S=/workspace/studio
[ -d "$S/src/episodes" ] || { echo "can't find $S/src/episodes"; exit 1; }
mkdir -p "$S/src/episodes/dossier"
cp engine/dossier.tsx "$S/src/engine/dossier.tsx"
cp episode/shots.tsx episode/index.tsx episode/timeline.json "$S/src/episodes/dossier/"
ENG="$S/src/engine/index.ts"
grep -q "from './dossier'" "$ENG" || echo "export * from './dossier';" >> "$ENG"
IDX="$S/src/episodes/index.ts"
grep -q "from './dossier'" "$IDX" || sed -i "1i import { dossierDemo } from './dossier';" "$IDX"
grep -q "EPISODES = \[.*dossierDemo" "$IDX" || sed -i "s/EPISODES = \[/EPISODES = [dossierDemo, /" "$IDX"
echo "--- $IDX:"; cat "$IDX"
echo "OK: Dossier kit installed."
