#!/bin/sh
# Installs Dossier + Cast + VET packs and the veterans episodes (Vet00..Vet99 and VetFull) into /workspace/studio. Safe to run twice.
set -e
S=/workspace/studio
[ -d "$S/src/episodes" ] || { echo "can't find $S/src/episodes"; exit 1; }
rm -rf "$S/src/episodes/vet"
mkdir -p "$S/src/episodes/vet" "$S/public/vet"
cp engine/dossier.tsx engine/cast.tsx engine/vet.tsx "$S/src/engine/"
cp episode/scene.tsx episode/index.tsx episode/specs.json episode/timelines.json "$S/src/episodes/vet/"
cp voice/*.mp3 "$S/public/vet/"
ENG="$S/src/engine/index.ts"
for m in dossier cast vet; do grep -q "from './$m'" "$ENG" || echo "export * from './$m';" >> "$ENG"; done
IDX="$S/src/episodes/index.ts"
grep -q "from './vet'" "$IDX" || sed -i "1i import { vetEpisodes } from './vet';" "$IDX"
grep -q "EPISODES = \[.*vetEpisodes" "$IDX" || sed -i "s/EPISODES = \[/EPISODES = [...vetEpisodes, /" "$IDX"
echo "--- $IDX:"; cat "$IDX"
echo "OK: veterans episodes installed."
