import { defineEpisode, Timeline } from '../../engine';
import { mk, Spec } from './scene';
import specs from './specs.json';
import tls from './timelines.json';

// "7 legendary veterans": one episode per voice clip (Vet00 ... Vet99) and VetFull (everything). Military pack only.
const SHOTS = Object.fromEntries(Object.entries(specs as unknown as Record<string, Spec>).map(([id, sp]) => [id, mk(id, sp)]));
export const vetEpisodes = Object.entries(tls).map(([id, tl]) => defineEpisode(id, { timeline: tl as unknown as Timeline, shots: SHOTS }));
